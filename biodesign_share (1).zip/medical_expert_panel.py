from __future__ import annotations

import os
import json
import logging
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime
from dotenv import load_dotenv
from camel.agents import ChatAgent
from camel.messages import BaseMessage
from camel.models import ModelFactory
from camel.types import ModelPlatformType, ModelType
from evidence_grounding import EvidenceGrounder
from prompts import *

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
load_dotenv()

@dataclass
class DiscussionState:
    observation: str
    language: str
    project_context: dict = field(default_factory=dict)
    known_constraints: str = ""
    evidence_available: str = ""
    started_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    completed_at: str = ""
    workflow_version: str = "biodesign-debate-v1"
    needs_brief: str = ""
    case_packet: str = ""
    specified_need: str = ""
    messages: list = field(default_factory=list)
    fact_checks: list = field(default_factory=list)
    claims: list = field(default_factory=list)
    evidence_gaps: list = field(default_factory=list)
    evidence_grounding: list = field(default_factory=list)
    risks: list = field(default_factory=list)
    options: list = field(default_factory=list)
    mcdm_scores: dict = field(default_factory=dict)
    sensitivity_analysis: dict = field(default_factory=dict)
    need_statement_versions: list = field(default_factory=list)
    bias_review: str = ""
    devil_challenge: str = ""
    final_report: str = ""
    final_need_statement: str = ""
    need_statement_quality: dict = field(default_factory=dict)
    identify_portfolio: str = ""
    need_profile: str = ""
    screening_result: str = ""
    validation_plan: str = ""
    need_criteria: str = ""
    # Invent phase outputs
    invent_brainstorm_text: str = ""
    invent_options_text: str = ""
    invent_debate_summary: str = ""
    invent_mcdm_report: str = ""
    mcdm_weights: dict = field(default_factory=lambda: {
        "System Impact": 0.40,
        "Implementability": 0.25,
        "Risk Control": 0.20,
        "Innovation": 0.10,
        "Cost-Benefit": 0.05,
    })

    def add_message(self, phase: str, role: str, content: str):
        self.messages.append({
            "phase": phase,
            "role": role,
            "content": content,
        })

    def add_fact_check(self, phase: str, source_role: str, source_statement: str, fact_report: str):
        self.fact_checks.append({
            "phase": phase,
            "source_role": source_role,
            "source_statement": source_statement,
            "fact_report": fact_report,
        })

    def add_need_statement_version(self, phase: str, role: str, statement: str):
        if statement and EnhancedMedicalPanel._is_likely_need_statement(statement):
            self.need_statement_versions.append({
                "phase": phase,
                "role": role,
                "statement": statement,
            })

    def to_dict(self):
        data = asdict(self)
        data["agent_messages"] = data["messages"]
        return data

class EnhancedMedicalPanel:
    def __init__(self, model_name="qwen3.5:4b"):
        self.evidence_grounder = EvidenceGrounder(project_root=os.getcwd())
        self.model_name = model_name
        self.current_provider = os.getenv("LLM_PROVIDER", "OLLAMA").upper()
        self.fallback_chain = self._build_fallback_chain(self.current_provider)
        self.active_model_index = 0
        model = self._create_model(self.fallback_chain[self.active_model_index])

        self._configure_agents(model)
        self.last_discovery_log = None

    def _build_fallback_chain(self, primary_provider: str) -> list:
        configured = os.getenv("MODEL_FALLBACK_CHAIN", "")
        if configured.strip():
            chain = [primary_provider] + [item.strip().upper() for item in configured.split(",") if item.strip()]
        else:
            chain = [primary_provider, "OLLAMA", "OMLX", "GEMINI", "OPENAI"]
        deduped = []
        for provider in chain:
            if provider not in deduped:
                deduped.append(provider)
        return deduped

    def _create_model(self, provider: str):
        common_model_config = {"max_tokens": 4096, "temperature": 0.7}
        cloud_model_config = {**common_model_config, "timeout": 600.0}

        if provider == "OPENAI":
            logger.info("Starting Enhanced Biodesign Expert Panel | Using Cloud OpenAI Model")
            return ModelFactory.create(
                model_platform=ModelPlatformType.OPENAI,
                model_type=ModelType.GPT_4O_MINI,
                model_config_dict=cloud_model_config
            )
        elif provider == "GEMINI":
            logger.info("Starting Enhanced Biodesign Expert Panel | Using Cloud Gemini API (Gemma 4 26B)")
            # Update the enum value to use Gemma 4 26B model supported by Gemini API
            ModelType.GEMINI_1_5_FLASH._value_ = "gemma-4-26b-a4b-it"

            return ModelFactory.create(
                model_platform=ModelPlatformType.GEMINI,
                model_type=ModelType.GEMINI_1_5_FLASH,
                model_config_dict=cloud_model_config
            )
        elif provider == "OMLX":
            model_name = os.getenv("OMLX_MODEL", "Qwen3.5-9B-MLX-4bit")
            url = os.getenv("OMLX_URL", "http://127.0.0.1:8989/v1")
            api_key = os.getenv("OMLX_API_KEY") or os.getenv("OPENAI_API_KEY") or "omlx"
            logger.info(f"Starting Enhanced Biodesign Expert Panel | Using Local oMLX Model: {model_name}")
            return ModelFactory.create(
                model_platform=ModelPlatformType.OPENAI_COMPATIBILITY_MODEL,
                model_type=model_name,
                url=url,
                api_key=api_key,
                model_config_dict=cloud_model_config
            )
        elif provider in {"OLLAMA_CLOUD", "OLLAMA-CLOUD", "OLLAMACLOUD"}:
            model_name = os.getenv("OLLAMA_CLOUD_MODEL") or os.getenv("OLLAMA_MODEL", "gpt-oss:120b")
            url = os.getenv("OLLAMA_CLOUD_URL", "https://ollama.com/v1")
            api_key = os.getenv("OLLAMA_API_KEY")
            if not api_key:
                raise RuntimeError(
                    "OLLAMA_API_KEY is required when LLM_PROVIDER=OLLAMA_CLOUD. "
                    "Add it to your .env file or shell environment."
                )
            logger.info(f"Starting Enhanced Biodesign Expert Panel | Using Ollama Cloud Model: {model_name}")
            return ModelFactory.create(
                model_platform=ModelPlatformType.OPENAI_COMPATIBILITY_MODEL,
                model_type=model_name,
                url=url,
                api_key=api_key,
                model_config_dict={**cloud_model_config, "top_p": 0.9}
            )
        else:
            model_name = os.getenv("OLLAMA_MODEL", self.model_name)
            url = os.getenv("OLLAMA_URL", "http://localhost:11434/v1")
            logger.info(f"Starting Enhanced Biodesign Expert Panel | Using Local Ollama Model: {model_name}")
            return ModelFactory.create(
                model_platform=ModelPlatformType.OLLAMA,
                model_type=model_name,
                url=url,
                model_config_dict={**common_model_config, "top_p": 0.9}
            )

    def _configure_agents(self, model):
        # ── 7-Agent Reduced Structure ────────────────────────────────────
        # Agent 1: Intake Analyzer (Case Packet Extractor + Needs Source Agent)
        self.intake_analyzer = ChatAgent(BaseMessage.make_assistant_message(role_name="Intake Analyzer", content=INTAKE_ANALYZER_PROMPT), model=model)
        # Agent 2: Clinical-Technical Expert (Clinical Physician + Biomedical Engineer)
        self.clinical_technical = ChatAgent(BaseMessage.make_assistant_message(role_name="Clinical-Technical Expert", content=CLINICAL_TECHNICAL_EXPERT_PROMPT), model=model)
        # Agent 3: Regulatory-Business Expert (Regulatory Expert + Market & IP Expert)
        self.regulatory_business = ChatAgent(BaseMessage.make_assistant_message(role_name="Regulatory-Business Expert", content=REGULATORY_BUSINESS_EXPERT_PROMPT), model=model)
        # Agent 4: Human-Patient Expert (Human Factors + Patient & Access Expert)
        self.human_patient = ChatAgent(BaseMessage.make_assistant_message(role_name="Human-Patient Expert", content=HUMAN_PATIENT_EXPERT_PROMPT), model=model)
        # Agent 5: Option Formation Agent (unchanged)
        self.option_former = ChatAgent(BaseMessage.make_assistant_message(role_name="Option Formation Agent", content=OPTION_FORMATION_PROMPT), model=model)
        # Agent 6: Critical Review Agent (Devil's Advocate + Fact Checker + Bias Detector)
        self.critical_reviewer = ChatAgent(BaseMessage.make_assistant_message(role_name="Critical Review Agent", content=CRITICAL_REVIEW_AGENT_PROMPT), model=model)
        # Agent 7: Consolidated Evaluator (MCDM + Portfolio — replaces Evaluator + Portfolio Agent)
        self.evaluator = ChatAgent(BaseMessage.make_assistant_message(role_name="Consolidated Evaluator", content=CONSOLIDATED_EVALUATOR_WITH_PORTFOLIO_PROMPT), model=model)

        self.all_agents = [
            self.intake_analyzer,
            self.clinical_technical,
            self.regulatory_business,
            self.human_patient,
            self.option_former,
            self.critical_reviewer,
            self.evaluator,
        ]

        self.agent_role_map = {
            self.intake_analyzer: "Intake Analyzer",
            self.clinical_technical: "Clinical-Technical Expert",
            self.regulatory_business: "Regulatory-Business Expert",
            self.human_patient: "Human-Patient Expert",
            self.option_former: "Option Formation Agent",
            self.critical_reviewer: "Critical Review Agent",
            self.evaluator: "Consolidated Evaluator",
        }

        self.expert_map = {
            "Clinical-Technical Expert": self.clinical_technical,
            "Regulatory-Business Expert": self.regulatory_business,
            "Human-Patient Expert": self.human_patient,
        }

        self.role_to_agent_attr = {
            "Intake Analyzer": "intake_analyzer",
            "Clinical-Technical Expert": "clinical_technical",
            "Regulatory-Business Expert": "regulatory_business",
            "Human-Patient Expert": "human_patient",
            "Option Formation Agent": "option_former",
            "Critical Review Agent": "critical_reviewer",
            "Consolidated Evaluator": "evaluator",
        }

    def _switch_to_next_model(self) -> bool:
        for index in range(self.active_model_index + 1, len(self.fallback_chain)):
            provider = self.fallback_chain[index]
            try:
                logger.warning(f"Switching model provider fallback to {provider}")
                model = self._create_model(provider)
            except Exception as exc:
                logger.warning(f"Could not initialize fallback provider {provider}: {exc}")
                continue
            self.active_model_index = index
            self.current_provider = provider
            self._configure_agents(model)
            return True
        return False

    def _broadcast_message(self, sender_agent, content: str):
        from camel.types import OpenAIBackendRole
        from camel.messages import BaseMessage
        sender_role_name = self.agent_role_map.get(sender_agent, "System")
        for agent in self.all_agents:
            if agent == sender_agent:
                agent.update_memory(
                    BaseMessage.make_assistant_message(role_name=sender_role_name, content=content),
                    OpenAIBackendRole.ASSISTANT
                )
            else:
                agent.update_memory(
                    BaseMessage.make_user_message(role_name=sender_role_name, content=content),
                    OpenAIBackendRole.USER
                )

    @staticmethod
    def _clean_model_content(content: str) -> str:
        """Remove reasoning traces some local models emit before showing output."""
        if not isinstance(content, str):
            return content
        cleaned = re.sub(r"<thought>.*?</thought>", "", content, flags=re.DOTALL | re.IGNORECASE)
        cleaned = re.sub(r"<think>.*?</think>", "", cleaned, flags=re.DOTALL | re.IGNORECASE)
        return cleaned.strip()

    def _ask(self, agent, content: str):
        import time
        # Do not reset agent memory here anymore to maintain conversation flow context
        msg = BaseMessage.make_user_message(role_name="User", content=content)
        provider = self.current_provider
        role = self.agent_role_map.get(agent)

        max_retries = 3
        for i in range(max_retries):
            try:
                if provider == "GEMINI":
                    # Free tier limit is 5 RPM, meaning 1 request per 12 seconds
                    time.sleep(13)
                response = agent.step(msg)
                if response and response.msg:
                    response.msg.content = self._clean_model_content(response.msg.content)
                return response
            except Exception as e:
                if "429" in str(e) or "ResourceExhausted" in str(e) or "Quota exceeded" in str(e):
                    if i < max_retries - 1:
                        print(f"\n[System] Rate limit hit. Waiting 60 seconds before retrying...")
                        time.sleep(60)
                    else:
                        if role and self._switch_to_next_model():
                            replacement = getattr(self, self.role_to_agent_attr[role])
                            return self._ask(replacement, content)
                        raise e
                else:
                    if role and self._switch_to_next_model():
                        replacement = getattr(self, self.role_to_agent_attr[role])
                        return self._ask(replacement, content)
                    raise e

    @staticmethod
    def _language_mismatch(content: str, cjk_output: bool) -> bool:
        text = re.sub(r"https?://\S+|`[^`]*`|\[[^\]]*\]", " ", content or "")
        cjk_chars = len(re.findall(r"[\u4e00-\u9fff]", text))
        ascii_words = len(re.findall(r"\b[A-Za-z][A-Za-z-]{2,}\b", text))
        if cjk_output:
            return ascii_words > 25 and ascii_words > max(cjk_chars * 0.8, 12)
        return cjk_chars > 30

    def _ask_language_checked(self, agent, content: str, proposal: str, cjk_output: bool):
        response = self._ask(agent, content)
        if not response or not response.msg:
            return response
        if self._language_mismatch(response.msg.content, cjk_output):
            target_language = "Traditional Chinese" if cjk_output else "English"
            rewrite_prompt = (
                f"{self._language_instruction(proposal)}\n\n"
                f"Rewrite the following response fully in {target_language}. "
                "Do not add new analysis. Preserve citations, acronyms, proper nouns, and numbers.\n\n"
                f"Response to rewrite:\n{response.msg.content}"
            )
            rewritten = self._ask(agent, rewrite_prompt)
            if rewritten and rewritten.msg:
                return rewritten
        return response

    @staticmethod
    def _language_instruction(proposal: str) -> str:
        return (
            "CRITICAL LANGUAGE INSTRUCTION:\n"
            f"- The user's clinical observation is: {proposal}\n"
            "- Detect the language of that observation and write your entire visible response in that same language.\n"
            "- If the observation is written in Traditional Chinese, use Traditional Chinese headings and prose.\n"
            "- Preserve acronyms, citations, model names, device names, and regulatory terms when appropriate.\n"
            "- Do not switch to English merely because the role instructions or source material are in English."
        )

    @staticmethod
    def _localized_fact_check_prompt(proposal: str, role: str, statement: str) -> str:
        return (
            f"{EnhancedMedicalPanel._language_instruction(proposal)}\n\n"
            f"Task: Verify the statement by {role}.\n"
            "Output requirements:\n"
            "1. Use concise headings in the same language as the clinical observation.\n"
            "2. Mark each major claim as accurate, questionable, unsupported, or inaccurate.\n"
            "3. Keep citations, PMID, URLs, guideline names, and acronyms in their original form.\n\n"
            f"Statement to verify:\n{statement}"
        )

    @staticmethod
    def _uses_cjk(text: str) -> bool:
        return bool(re.search(r"[\u4e00-\u9fff]", text or ""))

    def _display_role(self, role: str, proposal: str) -> str:
        if not self._uses_cjk(proposal):
            return role
        return {
            "Intake Analyzer": "需求萃取分析師",
            "Clinical-Technical Expert": "臨床技術專家",
            "Regulatory-Business Expert": "法規商業專家",
            "Human-Patient Expert": "人因病患專家",
            "Option Formation Agent": "方案形成代理人",
            "Critical Review Agent": "批判審查代理人",
            "Consolidated Evaluator": "整合評估者",
            # Legacy role names (for fallback compatibility)
            "Fact Checker": "批判審查代理人",
            "Bias Detector": "批判審查代理人",
            "Needs Source Agent": "需求萃取分析師",
            "Case Packet Extractor": "需求萃取分析師",
            "Regulatory Expert": "法規商業專家",
            "Market & IP Expert": "法規商業專家",
            "Human Factors Expert": "人因病患專家",
            "Patient & Access Expert": "人因病患專家",
            "Identify Portfolio Agent": "整合評估者",
        }.get(role, role)

    @staticmethod
    def _extract_markdown_section(text: str, heading_keywords: list) -> str:
        if not text:
            return ""
        headings = list(re.finditer(r"^(#{1,4})\s*(.+?)\s*$", text, flags=re.MULTILINE))
        for index, match in enumerate(headings):
            title = match.group(2).strip().lower()
            if any(keyword.lower() in title for keyword in heading_keywords):
                start = match.start()
                end = headings[index + 1].start() if index + 1 < len(headings) else len(text)
                return text[start:end].strip()
        return ""

    @staticmethod
    def _extract_need_statement(final_report: str) -> str:
        if not final_report:
            return ""
        patterns = [
            r"(?:初步需求陳述|候選需求陳述|建議修正的需求陳述|最終\s*Need Statement|最終需求陳述|Perfect Need Statement|需求陳述|需求聲明)\s*(?:[（(][^）)]*[）)])?\s*[:：]\s*(?:\*\*)?[「\"]?([^\n」\"]+)",
            r"(?:Final Solution-Free Need Statement|Final Need Statement|Need Statement)\s*[:：]\s*(?:\*\*)?[\"']?((?:A way to|A method to)[^\n\"']+)",
            r"「([^」]*(?:一種|能夠)[^」]*方法[^」]*)」",
            r"\*\*([^*\n]*(?:一種|能夠)[^*\n]*方法[^*\n]*)\*\*",
            r"((?:A way to|A method to)\s+.+?\s+to\s+.+?)(?:\n|$)",
            r"(一種能夠.+?的方法)(?:[。.\n]|$)",
        ]
        for pattern in patterns:
            match = re.search(pattern, final_report, flags=re.IGNORECASE | re.DOTALL)
            if match:
                statement = re.sub(r"^[#*\-\s:：]+", "", match.group(1)).strip()
                statement = statement.splitlines()[0].strip()
                statement = statement.strip("* 「」\"'")
                if EnhancedMedicalPanel._is_likely_need_statement(statement):
                    return statement
        return ""

    @staticmethod
    def _is_likely_need_statement(statement: str) -> bool:
        text = (statement or "").strip()
        if EnhancedMedicalPanel._looks_like_placeholder_need(text):
            return False
        lowered = text.lower()
        rejected_fragments = [
            "need statement / criteria", "need statement 若", "criteria",
            "過早綁定", "技術或產品形式", "提醒", "待驗證", "n/a",
        ]
        if any(fragment in lowered for fragment in rejected_fragments):
            return False
        if EnhancedMedicalPanel._uses_cjk(text):
            return "一種" in text and "方法" in text and ("以達成" in text or "降低" in text or "改善" in text or "提升" in text)
        return bool(re.search(r"\bA way to\b.+\bto\b", text, re.IGNORECASE))

    @staticmethod
    def _looks_like_placeholder_need(statement: str) -> bool:
        text = (statement or "").strip()
        if not text:
            return True
        placeholder_terms = [
            "[verb]", "[population]", "[measurable outcome]", "[x]", "[y]", "[score]",
            "please provide", "i will", "once received", "standing by", "example",
            "請提供", "範例", "等待", "尚未提供",
            "相關臨床操作者", "更安全、更穩定之操作流程",
            "導尿管", "cauti", "biofilm", "生物薄膜",
            "立場分析", "請提交", "操作約束", "交戰規則",
        ]
        lowered = text.lower()
        return any(term in lowered for term in placeholder_terms)

    @staticmethod
    def _topic_terms(text: str) -> set:
        text = text or ""
        stop_terms = {
            "過程", "需要", "頻繁", "每次", "必須", "重新", "更換", "消毒",
            "方法", "情況", "目標", "結果", "提供", "臨床", "需求", "方案",
        }
        terms = set()
        terms.update(re.findall(r"[A-Za-z][A-Za-z0-9-]{3,}", text.lower()))
        cjk_chunks = re.findall(r"[\u4e00-\u9fff]{2,}", text)
        for chunk in cjk_chunks:
            if 2 <= len(chunk) <= 8 and chunk not in stop_terms:
                terms.add(chunk)
            for size in (2, 3):
                for index in range(max(len(chunk) - size + 1, 0)):
                    term = chunk[index:index + size]
                    if term not in stop_terms:
                        terms.add(term)
        return terms

    @classmethod
    def _is_topic_aligned(cls, source: str, output: str, min_matches: int = 3) -> bool:
        source_terms = cls._topic_terms(source)
        if not source_terms:
            return True
        output_text = (output or "").lower()
        matches = [term for term in source_terms if term and term.lower() in output_text]
        return len(matches) >= min_matches

    @staticmethod
    def _looks_like_missing_input_response(content: str) -> bool:
        text = (content or "").lower()
        red_flags = [
            "請提供需求陳述",
            "請提供臨床觀察",
            "尚未提供具體",
            "standing by",
            "ready for input",
            "please provide",
            "我已準備好",
            "我已在線",
            "我已準備好接收",
            "準備就緒",
            "主動監控",
            "準備接收輸入",
            "請提供辯論",
            "貼上辯論",
            "一旦收到",
            "請提供您目前",
            "等待您的輸入",
            "進行審核",
            "請提交您的提案",
            "請提交您的",
            "提交要求",
            "請提供您的",
            "我的操作框架",
            "操作框架",
            "我的報告協議",
            "報告格式",
            "如何與我協作",
            "當你提交",
            "當您提出提案",
            "當您提交",
            "我將應用以下框架",
            "我會將",
            "i am ready",
            "i'm ready",
            "submit your proposal",
            "submission requirements",
            "when you provide",
            "when you submit",
            "my operating framework",
            "my reporting protocol",
            "示例",
            "[示例]",
            "example",
            "cauti",
            "導尿管",
            "生物薄膜",
            "biofilm",
            # ── Human-Patient Expert Round 2 "ready" template patterns ──────
            "我準備好了",
            "我已將我的雙重視角內化",
            "請提出問題或需求陳述",
            "請提供您希望分析的",
            "一旦提供",
            "我將應用以下嚴格",
            "我正待命",
            "分析框架如下",
            "請提出問題",
            "我將專注於",
            "我不會推測設備",
            "我不會推測",
            "請提供問題",
        ]
        return any(flag in text for flag in red_flags)

    @staticmethod
    def _looks_like_phase2_critique(content: str) -> bool:
        text = content or ""
        role_mentions = [
            "Clinical-Technical Expert", "Regulatory-Business Expert",
            "Human-Patient Expert", "Critical Review Agent",
            "Clinical Physician", "Biomedical Engineer", "Regulatory Expert",
            "Market & IP Expert", "Human Factors Expert",
            "Patient & Access Expert", "Fact Checker",
            "臨床", "工程", "法規", "市場", "智財", "人因", "可近性", "體驗", "事實查核",
        ]
        critique_terms = [
            "第二階段", "Phase 2", "專家立場", "position", "assumption",
            "假設", "矛盾", "張力", "缺口", "evidence gap", "scope",
        ]
        return (
            sum(1 for item in role_mentions if item in text) >= 2
            and any(term.lower() in text.lower() for term in critique_terms)
        )

    @staticmethod
    def _remove_repeated_case_blocks(content: str) -> str:
        if not content:
            return content
        lines = content.splitlines()
        cleaned = []
        skip = False
        skip_until_headings = [
            "專業視角", "本角色的專業解讀", "我看到的核心問題",
            "針對候選議題的提醒", "關鍵假設", "必須驗證",
            "需要驗證", "議題排序", "批判視角", "我不同意",
        ]
        skip_markers = [
            "本案臨床觀察：", "Clinical observation addressed:",
            "候選議題：", "Issue 1 -", "Issue ID:",
        ]
        for line in lines:
            stripped = line.strip()
            if any(marker in stripped for marker in skip_markers):
                skip = True
                continue
            if skip and any(heading in stripped for heading in skip_until_headings):
                skip = False
            if not skip:
                cleaned.append(line)
        result = "\n".join(cleaned).strip()
        result = re.sub(r"###\s+(.+?)\s+對本案的專家立場", r"### \1｜專家提醒", result)
        return result or content

    @staticmethod
    def _compact_shared_state(
        proposal: str,
        needs_brief: str,
        final_need_statement: str = "",
        evidence_gaps: list | None = None,
        risks: list | None = None,
    ) -> str:
        evidence_lines = []
        for item in (evidence_gaps or [])[:8]:
            if isinstance(item, dict):
                evidence_lines.append(item.get("gap", ""))
            else:
                evidence_lines.append(str(item))
        risk_lines = [str(item) for item in (risks or [])[:8]]
        return (
            f"Original clinical observation:\n{proposal}\n\n"
            f"Need discovery brief:\n{needs_brief[:2500]}\n\n"
            f"Current solution-free Need Statement:\n{final_need_statement or 'N/A'}\n\n"
            "Evidence gaps:\n"
            + "\n".join(f"- {line}" for line in evidence_lines if line)
            + "\n\nRisks:\n"
            + "\n".join(f"- {line}" for line in risk_lines if line)
        )

    @staticmethod
    def _grounded_round_retry_prompt(
        proposal: str,
        lang_instruction: str,
        lang_name: str,
        role: str,
        round_name: str,
        required_focus: str,
        shared_state: str,
    ) -> str:
        return (
            f"{lang_instruction}\n\n"
            f"You are the {role}. You must answer as part of the {round_name}.\n"
            "Your previous response did not address the assigned case materials. "
            "Do not introduce your role, operating framework, report protocol, or ask the user to submit a proposal. "
            "Do not provide a generic template. "
            "Use only the clinical observation and assigned shared state below.\n\n"
            f"Clinical observation:\n{proposal}\n\n"
            f"Required focus:\n{required_focus}\n\n"
            f"Shared state:\n{shared_state[-7000:]}\n\n"
            f"Write a concrete, case-specific response in {lang_name}."
        )

    @staticmethod
    def _parse_case_packet(text: str) -> dict:
        packet = {
            "clinical_field": "本案臨床領域",
            "main_operator": "主要操作者",
            "problem_action": "臨床問題動作",
            "consequences": "不良後果",
            "current_workaround": "現有替代做法",
            "outcome_to_improve": "待改善指標",
            "issue_candidates": "候選議題",
        }
        if not text:
            return packet
        
        headers = [
            ("clinical_field", ["clinical field", "臨床領域與環境"]),
            ("main_operator", ["main operator", "主要操作者"]),
            ("problem_action", ["problematic action", "問題動作"]),
            ("consequences", ["consequence", "造成的後果"]),
            ("current_workaround", ["workaround", "目前替代方案"]),
            ("outcome_to_improve", ["outcome", "待改善指標"]),
            ("issue_candidates", ["issue candidates", "候選議題"]),
        ]
        
        for key, keywords in headers:
            section = EnhancedMedicalPanel._extract_markdown_section(text, keywords)
            if section:
                lines = section.splitlines()
                if lines:
                    content_lines = [re.sub(r"^[-*]\s+", "", line.strip()) for line in lines[1:] if line.strip()]
                    packet[key] = " ".join(content_lines)
        return packet

    @staticmethod
    def _case_specific_fallback_response(
        role: str,
        phase: str,
        proposal: str,
        cjk_output: bool,
        case_packet_text: str = "",
        position_context: str = "",
    ) -> str:
        packet = EnhancedMedicalPanel._parse_case_packet(case_packet_text) if case_packet_text else {
            "clinical_field": "本案臨床環境",
            "main_operator": "主要操作者",
            "problem_action": "臨床問題動作",
            "consequences": "不良後果",
            "current_workaround": "現有替代做法",
            "outcome_to_improve": "待改善指標",
            "issue_candidates": "候選議題",
        }
        
        case_focus = (
            f"本案的具體工作流是：在 {packet['clinical_field']} 的環境中，{packet['main_operator']} 執行操作時，"
            f"會發生 {packet['problem_action']}，這造成了 {packet['consequences']} 的後果。"
            f"目前採用的替代方案是 {packet['current_workaround']}。"
        )
        issue_candidates = packet.get("issue_candidates") or "尚未拆分候選議題。"
        
        if not cjk_output:
            if "Critique" in phase or "批判" in phase:
                return (
                    f"Case-specific critique from {role}:\n\n"
                    f"- Clinical observation addressed: {proposal}\n"
                    f"- Workflow context: {packet['clinical_field']}, operator: {packet['main_operator']}\n"
                    "- Cross-examination: the Phase 2 claims should not be accepted until the team verifies actual workflow frequency, stakeholder urgency, and current workaround burden.\n"
                    f"- Problem Action: {packet['problem_action']} causing {packet['consequences']}.\n"
                    "- Assumption to challenge: experts may be inferring clinical importance from inconvenience without enough quantitative evidence.\n"
                    f"- Evidence gap: collect direct observations on {packet['current_workaround']} and verify {packet['outcome_to_improve']}.\n"
                    "- Scope parameter: the final Need Statement must stay solution-free and focus on the affected population, setting, workflow moment, and measurable outcome."
                )
            return (
                f"Case-specific position from {role}:\n\n"
                f"- Clinical observation addressed: {proposal}\n"
                f"- Workflow context: {packet['clinical_field']}, operator: {packet['main_operator']}\n"
                "- Interpretation: this is a workflow and unmet-need framing problem, not yet a product concept.\n"
                f"- Key assumption: the observed burden of {packet['problem_action']} causing {packet['consequences']} is frequent and consequential enough to justify validation.\n"
                f"- Evidence needed: frequency, severity, stakeholder urgency, and effectiveness of current workaround: {packet['current_workaround']}.\n"
                f"- Need Statement parameter: define the population, care setting, workflow moment, and target outcome: {packet['outcome_to_improve']}."
            )

        if ("Round 1" in phase or "初始立場" in phase or "專家立場" in phase) and role == "Regulatory-Business Expert":
            return (
                "### Regulatory-Business Expert｜Round 1 立場\n\n"
                "**專業視角：** 法規分類預判、技術路線分岔、感染控制標準與台灣健保結構對採購誘因的影響。\n\n"
                "**主要觀察：**\n"
                "- **設備分類預判**：若後續方案為被動輔助（純機械固定或位置調整），FDA 傾向 Class II 510(k)，TFDA 傾向第一類或第二類；若方案涉及主動控制（馬達驅動、感測器反饋、軟體決策），FDA 可能需要 De Novo，TFDA 升為第二類且需技術審查，驗證成本與時間至少翻倍。**被動 vs. 主動是目前最關鍵的法規分岔點，必須在 Invent 入口前確認。**\n"
                "- **感染控制**：任何可重複使用的口腔內器材必須符合 ISO 17664（製造商需提供清潔、消毒、滅菌程序驗證）。若設計含電子元件或複雜機構，Autoclave 相容性是設計約束，不是後期問題。一次性方案則需 ISO 10993 生物相容性測試。\n"
                "- **IEC 62366**：Class II 及以上器材需要 Human Factors Validation（HFV）報告，成本與時間尚未納入評估。\n"
                "- **台灣健保結構**：根管治療依「牙根數」計費，與治療時間無關，導致「效率工具」在健保端缺乏採購誘因。商業化路徑需轉向「安全工具」框架，或鎖定自費診所與出口市場。\n\n"
                "**必須驗證：**\n"
                "- 中斷是否造成可量化的椅旁時間損失（time-motion 影片）。\n"
                "- 診所管理者的採購門檻與付費意願——尤其在健保給付不支持效率改善的情況下。\n\n"
                "**需要的證據：**\n"
                "- 10-20 件複雜根管案例的 time-motion 影片。\n"
                "- TFDA 豁免清單查詢：被動輔助方案是否符合豁免條件；TFDA 預諮詢（Pre-submission Meeting）評估。\n"
                "- 診所端訪談：牙醫師、助理、診所管理者的採購決策框架與願付價格。\n\n"
                "**優先議題建議：** IC-1 優先，但進入 Invent 前必須確認兩件事：(1) 被動 vs. 主動的技術路線選擇；(2) 感染控制路徑（可重複使用 vs. 一次性）。這兩個選擇直接決定法規類別、材料選擇與成本結構。"
            )

        if ("Round 1" in phase or "初始立場" in phase or "專家立場" in phase) and role == "Human-Patient Expert":
            return (
                "### Human-Patient Expert｜Round 1 立場\n\n"
                "**專業視角：** 三工競爭雙手的認知負荷飽和、Reason's Model 錯誤模式分類、高齡患者特定人因與 IEC 62366 自動化偏誤風險。\n\n"
                "**主要觀察（CTA 與錯誤模式分析）：**\n"
                "- **認知資源飽和（Wickens 多重資源理論）**：助理在吸唾（Task A）+ 吹乾（Task B）同時執行時，運動輸出通道（Motor Output）被完全佔用，Task C（調整鏡子）物理上無法進行。這是幾何性限制，與訓練或技巧無關。\n"
                "- **Slip 錯誤**：助理切換器械時，鏡子角度產生非預期位移——運動程序被打斷後重啟時角度難以精準復位。\n"
                "- **Lapse 錯誤**：醫師在視野短暫清晰後繼續操作，忘記確認根管深度標記——監控任務與操作任務的認知資源競爭導致記憶痕跡減弱。\n"
                "- **Mistake 錯誤**：助理判斷「吸唾比視野更緊急」而優先放棄視野維持——在訓練不足或 SOP 無明確優先順序時，此類決策錯誤系統性發生。\n"
                "- **Violation 違規**：醫師在視野不理想時繼續小幅度操作——因頻繁中斷的挫敗感會導致規範性行為逐步侵蝕。\n"
                "- **高齡患者特定人因**：TMJ 退化導致開口耐受度下降，每次中斷會觸發開口調整需求；輕度認知退化患者對「不要動」等口頭指令遵從性下降；每次暫停都放大「是不是出問題了？」的焦慮，進一步影響開口配合。\n"
                "- **IEC 62366 自動化偏誤風險（New Hazard）**：若後續方案涉及主動自動控制，操作者因長期依賴自動化而失去主動監控習慣，當感測器失效時無法即時介入。這是 IEC 62366 定義的 Foreseeable Misuse，需在 Need Criteria 中設立人因紅線。\n\n"
                "**必須驗證：**\n"
                "- 中斷是否真的增加患者張口疲勞、焦慮或配合度下降（VAS 量表）。\n"
                "- 若在 SOP 中明確規定三工優先順序，能消除多少 Mistake 類中斷？若 >50%，需求需重新定義為流程設計問題。\n\n"
                "**需要的證據：**\n"
                "- Task analysis 影片：記錄雙手佔用、視線轉移、口頭指令次數、器械切換次數、助理的 Mistake 模式選擇行為。\n"
                "- 患者訪談：張口疲勞、不適、治療焦慮、對中斷的主觀感受（NASA-TLX 或 VAS）。\n\n"
                "**優先議題建議：** IC-1 優先，但 Need Criteria 必須包含兩條人因紅線：(1) 不得增加操作者主動監控負擔；(2) 不得增加患者口腔內物理佔用或不適感。這兩條是任何 Invent 方案的硬性排除條件。"
            )

        if ("Review" in phase or "審查" in phase or "批判" in phase) and role == "Critical Review Agent":
            return (
                "### Critical Review Agent｜本輪審查\n\n"
                "**Part A – Devil's Advocate：** 最危險的共同假設是「視野中斷很頻繁且足以造成臨床/商業價值」。目前只有單一觀察，還不能排除它只是特定助理經驗、站位、rubber dam 使用、吸引配置或醫師習慣造成。\n\n"
                "**Part B – Fact Checker：** 需要查證的主張包括：複雜根管案例中視野中斷頻率、每次中斷秒數、高齡患者張口疲勞與中斷的關聯、現有隔離/吸引/反光鏡工具是否已可解決、診所願付價格與採購者。\n\n"
                "**Part C – Bias Detector：** 偵測到 solution anchoring 風險：團隊容易跳到「固定鏡子」或「自動調鏡」。目前應先保留為「同步水分控制與清晰視野維持」的需求，不指定鏡子、吸唾、固定架或自動化。"
            )

        role_profiles = {
            "Clinical-Technical Expert": {
                "lens": "臨床真實性、患者安全與工程可量測性",
                "interpretation": f"同時判斷 {packet['problem_action']} 是否構成真實、頻繁且嚴重的臨床問題，並把它轉成可量測的流程負擔、失效模式與後續需求參數。",
                "assumptions": [
                    f"{packet['consequences']} 具有足夠臨床嚴重度，而不只是流程不便。",
                    f"{packet['problem_action']} 能被量化為時間、錯誤率、風險、訊號品質、操作負擔或可靠度指標。",
                    "臨床安全風險與工程限制必須同時成立，否則不能推進為 Top Need。",
                ],
                "evidence": [
                    "直接觀察病例流程，記錄問題發生頻率、持續時間與患者安全後果。",
                    "訪談臨床操作者，確認哪些情境會讓問題升級成安全風險或治療品質下降。",
                    "建立 task / failure-mode map，定義後續可量測的 outcome metrics。",
                ],
                "criteria": [
                    "Need Statement 必須鎖定明確患者族群、臨床場景與可衡量結果。",
                    "Need Criteria 應描述工作流性能與安全要求，不應寫入裝置或技術形式。",
                ],
            },
            "Regulatory-Business Expert": {
                "lens": "法規驗證邊界、市場痛度、給付與智財空間",
                "interpretation": f"評估這個需求若成立，會牽涉哪些安全宣稱、驗證負擔、採購誘因、給付風險與 freedom-to-operate 不確定性。",
                "assumptions": [
                    "目前所有療效、安全、成本與市場主張都只能視為工作假設。",
                    "使用者覺得痛不代表購買者會付費；臨床、採購、給付與風險承擔者必須分開驗證。",
                    "Need Statement 若過早綁定技術或產品形式，會同時提高法規與 IP 風險。",
                ],
                "evidence": [
                    "確認現行 SOP、臨床指引、風險管理要求與可能的法規分類邊界。",
                    "訪談使用者、採購者與機構決策者，量化時間、耗材、人力或風險成本。",
                    "在進入 Invent 後才針對具體方案做 prior art、predicate 與 reimbursement 查證。",
                ],
                "criteria": [
                    "需求應避免尚未證實的療效或安全宣稱。",
                    "Top Need 應具備明確 stakeholder urgency 與可辯護的採用動機。",
                ],
            },
            "Human-Patient Expert": {
                "lens": "人因工作流、患者體驗、可近性與健康公平性",
                "interpretation": f"檢查 {packet['main_operator']} 在關鍵流程中的任務負荷、注意力切換與錯誤風險，同時判斷患者、照護者與低資源族群是否承受實質負擔。",
                "assumptions": [
                    "問題可能來自角色分工、視線取得、器械配置、溝通或環境限制，而非單一設備缺陷。",
                    "改善流程不能把負擔轉嫁給患者、照護者、護理人員或低資源場域。",
                    "不同候選議題對患者體驗與公平性的價值可能不同，應分開排序。",
                ],
                "evidence": [
                    "進行 task analysis，記錄雙手占用、視線轉移、口頭指令、中斷點與 near-miss。",
                    "訪談患者與照護者，確認焦慮、等待、疼痛、尊嚴或經濟負擔是否被放大。",
                    "比較不同資源、保險、地理位置與健康識能族群是否面臨不同程度的問題。",
                ],
                "criteria": [
                    "Need Criteria 應要求低訓練負擔、可融入既有流程，且不增加患者經濟或認知負擔。",
                    "Top Need 不應只服務高端、高自費或高資源場域。",
                ],
            },
            "Critical Review Agent": {
                "lens": "反方檢驗、事實查核與偏誤偵測",
                "interpretation": "質疑團隊是否把未驗證的觀察當成事實、把單一案例當成常態，或在 Identify 階段過早滑向產品方案。",
                "assumptions": [
                    "問題頻率、嚴重度、採用意願與市場痛度都尚未被證據充分支持。",
                    "候選議題可能被錯誤合併，導致 Need Statement 過寬或不可驗證。",
                    "專家可能受確認偏誤、權威偏誤、解方錨定或樂觀偏誤影響。",
                ],
                "evidence": [
                    "要求跨病例、跨操作者、跨場域重複觀察。",
                    "標記所有流行率、法規分類、給付、市場與技術就緒度主張的證據缺口。",
                    "要求團隊提出最能否定 Top Need 的反例與 kill criteria。",
                ],
                "criteria": [
                    "若證據不足，結論應是 Needs More Validation，而不是 Strong Candidate。",
                    "所有 final output 必須維持 solution-free，且清楚標示未驗證假設。",
                ],
            },
            "Clinical Physician": {
                "lens": "臨床醫療與患者安全",
                "interpretation": f"判斷 {packet['problem_action']} 是否代表真實且反覆出現的臨床風險，並區分流程不便、治療品質下降與患者安全事件。",
                "assumptions": [
                    f"{packet['consequences']} 在臨床上具有足夠嚴重度，而不只是短暫不便。",
                    f"{packet['main_operator']} 目前的處置方式會影響治療連續性、判斷品質或患者安全。",
                    "不同候選議題可能牽涉不同患者風險，不能直接合併成同一個 need。",
                ],
                "evidence": [
                    "直接觀察病例流程，記錄問題發生頻率與中斷時間。",
                    "訪談臨床人員，確認哪些情境會讓問題升級成安全風險。",
                    "蒐集與患者結果、治療延誤、併發症或臨床決策品質相關的資料。",
                ],
                "criteria": [
                    "Need Statement 必須鎖定明確患者族群與臨床場景。",
                    "結果指標需能反映安全性、治療連續性或治療品質。",
                ],
            },
            "Biomedical Engineer": {
                "lens": "工程需求與系統限制",
                "interpretation": f"把 {packet['problem_action']} 拆成可量測的工作流負載、空間限制、同步操作負擔與失效模式，但暫不提出任何技術方案。",
                "assumptions": [
                    "候選議題中的每個問題都可被量化為操作負擔、時間延遲、視野/資訊品質下降或安全裕度不足。",
                    "現行 workaround 的限制來自人手、環境、流程或資訊回饋不足，而不只是個別操作者技巧差異。",
                    "若兩個 issue 的機制不同，後續工程需求也會不同，應先分開評估。",
                ],
                "evidence": [
                    "建立 workflow map，量測同時操作的任務數、手部占用、反應時間與中斷點。",
                    "記錄環境限制，例如口腔空間、器械配置、噪音、液體、可視角度或監測資訊取得難度。",
                    "把每個候選議題轉成後續可用的需求參數，例如延遲、精度、可靠度、可用性、訊號品質或操作負擔。",
                ],
                "criteria": [
                    "Need Criteria 應描述要改善的工作流性能，不應寫入裝置或技術形式。",
                    "需定義未來解方不可增加操作者認知負荷或關鍵步驟中斷。",
                ],
            },
            "Regulatory Expert": {
                "lens": "法規宣稱與驗證邊界",
                "interpretation": f"先釐清需求是否涉及安全宣稱、監測宣稱或臨床結果改善宣稱；不同候選議題會導向不同驗證強度與風險等級。",
                "assumptions": [
                    "目前只能把臨床主張視為假設，不能直接宣稱能降低併發症或改善治療結果。",
                    "若 issue 涉及生理監測或高風險患者，驗證要求會高於單純流程效率問題。",
                    "需求陳述應避免過早暗示特定醫材分類或產品效能。",
                ],
                "evidence": [
                    "確認現行 SOP、專業指引與臨床風險管理要求。",
                    "釐清哪些 outcome 是流程指標，哪些是臨床安全指標。",
                    "定義後續驗證需用 observational data、human factors evidence 或 clinical evidence。",
                ],
                "criteria": [
                    "Need Statement 應聚焦 unmet need，不應包含法規尚未證實的安全或療效宣稱。",
                    "若選擇高風險患者監測議題，需明確列出驗證與風險管理邊界。",
                ],
            },
            "Market & IP Expert": {
                "lens": "市場痛度、採用動機、智財與 FTO 空間",
                "interpretation": f"評估 {packet['consequences']} 是否造成足夠的時間、風險或成本，讓機構願意付費改變；同時確認需求是否過早綁定已知技術形式而縮小 IP 保護空間。",
                "assumptions": [
                    "使用者覺得麻煩不等於採購者願意付費；決策者與使用者的誘因需分開評估。",
                    "越早把 need 寫成特定技術，越容易縮小後續 Invent 階段的可創新與可保護空間。",
                    "若問題只發生在少數高複雜病例，市場吸引力需要重新估算。",
                ],
                "evidence": [
                    "估算問題發生頻率、單次造成的時間/耗材/人力成本。",
                    "訪談使用者與決策者，分清楚誰痛、誰付錢、誰承擔風險。",
                    "確認每個候選議題是否已有明顯成熟替代方案；待進入 Invent 後再做 prior art / FTO 檢索。",
                ],
                "criteria": [
                    "Top Need 應具備明確 stakeholder urgency，且 need 須 solution-free 以保留 IP 空間。",
                    "Need Criteria 應包含不增加診所流程負擔與不依賴高成本導入。",
                ],
            },
            "Human Factors Expert": {
                "lens": "人因、任務負荷與工作流",
                "interpretation": f"檢查 {packet['main_operator']} 在關鍵時刻是否承受過高的同步任務負荷、注意力切換、手部占用或溝通負擔。",
                "assumptions": [
                    "問題可能來自角色分工、器械排列、視線取得、資訊回饋或交接，而非單一設備缺陷。",
                    "若解方增加新操作步驟，可能把問題從一個人轉嫁給另一個人。",
                    "候選議題應依任務負荷與錯誤風險分開評估。",
                ],
                "evidence": [
                    "進行 task analysis，記錄雙手占用、視線轉移、口頭指令與中斷點。",
                    "觀察不同操作者、助理配置與病例複雜度下問題是否重現。",
                    "收集 near-miss、延誤、重工與使用者挫折點。",
                ],
                "criteria": [
                    "Need Criteria 應要求不增加認知負荷與關鍵步驟切換。",
                    "需保留低訓練負擔、可融入既有流程的限制。",
                ],
            },
            "Patient & Access Expert": {
                "lens": "患者體驗、照護負擔、可近性與健康公平性",
                "interpretation": "從患者親身感受與結構性可近性兩個角度評估：這個需求若被解決，是否真正改善高風險或弱勢患者的照護體驗，還是只提升高資源診所效率？",
                "assumptions": [
                    "高齡、共病、焦慮或低健康識能患者可能受到不成比例影響。",
                    "改善流程不能讓患者承擔更高費用、更多等待、更多轉診或更高照護者負擔。",
                    "不同候選議題對患者的直接體驗與可近性價值不同，應分開排序。",
                ],
                "evidence": [
                    "訪談患者與照護者，確認恐懼、等待、中斷或併發症風險如何影響日常生活與治療意願。",
                    "比較不同資源、地理位置、保險狀況的患者是否面臨相同或更嚴重的問題。",
                    "評估若流程改變，患者自費、可近性、數位落差與照護不平等是否惡化。",
                ],
                "criteria": [
                    "Top Need 應避免只服務高端診所或高自費族群；需涵蓋可近性公平考量。",
                    "Need Criteria 應包含不增加患者經濟、認知或照護負擔的限制。",
                ],
            },
            "Devil's Advocate": {
                "lens": "反方檢驗與替代解釋",
                "interpretation": "質疑這些候選議題是否真的都是 unmet needs，或只是個案、訓練不足、流程未落實、設備設定不佳造成的表面現象。",
                "assumptions": [
                    "觀察到的中斷可能不代表常態。",
                    "現行 workaround 可能已足夠，只是尚未被正確使用。",
                    "把多個議題合併成單一 need 可能會掩蓋真正的核心痛點。",
                ],
                "evidence": [
                    "要求跨病例、跨操作者、跨場域重複觀察。",
                    "要求證明每個候選議題各自造成可量化後果。",
                    "要求比較訓練、SOP、角色分工調整是否已能解決問題。",
                ],
                "criteria": [
                    "若證據不足，結論應是 Needs More Validation，而不是 Strong Candidate。",
                    "Need Statement 應只鎖定被證據支持的主要議題。",
                ],
            },
        }
        profile = role_profiles.get(role, role_profiles.get("Devil's Advocate"))
        guidance = profile["interpretation"]

        def bullets(items):
            return "".join(f"- {item}\n" for item in items)

        if "Cross-Challenge" in phase or "交叉挑戰" in phase:
            # Each expert has a differentiated cross-challenge conclusion to create genuine debate tension.
            challenge_data = {
                "Clinical-Technical Expert": {
                    "expert_a": "Regulatory-Business Expert",
                    "challenge_a": "法規風險提醒停在分類層面，但沒有回答：若把需求框架改成「安全工具」（降低根管穿孔風險）而非「效率工具」，法規負擔到底是升高還是降低？這個問題直接決定 Need Statement 要不要加入安全結果作為 outcome，不能留到 Invent。",
                    "expert_b": "Human-Patient Expert",
                    "challenge_b": "人因分析說明了三工競爭雙手的物理限制，但沒有區分 Mistake 類錯誤（SOP 優先順序不清楚）和 Slip 類錯誤（物理干涉本身）。這兩種失效模式有不同的解法門檻——如果 SOP 標準化能消除 Mistake 類中斷，器材創新只需解決物理干涉，Need Statement 的範圍要對應調整。",
                    "agreement": "小組已正確把焦點放在 IC-1 的三工競爭雙手結構，以及高齡患者作為目標族群的限定。",
                    "scope_change": "Need Statement 必須加入邊界條件「在現有 SOP 執行情境下」，以確保需求針對的是物理與認知限制本身，而非流程設計缺陷。安全框架 vs. 效率框架的選擇在本輪應初步確定方向。",
                    "agreement_en": "The group correctly identified IC-1: three-task competing for two hands, and confirmed the elderly patient as target population.",
                    "scope_change_en": "Need Statement must add the boundary condition 'under current SOP execution' to ensure the need targets physical and cognitive constraints, not process design gaps. The safety vs. efficiency framing choice should be directionally resolved this round.",
                },
                "Regulatory-Business Expert": {
                    "expert_a": "Clinical-Technical Expert",
                    "challenge_a": "臨床與工程分析提出了中斷次數、恢復時間等指標，但我要挑戰一個更根本的問題：你主張把框架從「效率工具」轉向「安全工具」，但 Safety Claim 在 FDA 和 TFDA 端都需要 controlled clinical study 支撐，這會讓驗證成本翻倍。你確定這個框架轉換是用資料驅動的，而不是為了強化需求的可辯護性？在有根管穿孔率或 near-miss 的直接資料前，Safety Claim 應被標記為假設，而非作為 Need Statement 的 primary outcome。",
                    "expert_b": "Human-Patient Expert",
                    "challenge_b": "你提出的高齡患者特定人因（TMJ 耐受度、認知配合、焦慮放大）非常具體，但同時使目標族群更窄。市場規模因此需要更保守估算。更重要的是：你提到 IEC 62366 的自動化偏誤風險，但這代表任何主動控制方案都需要 HFV 報告，這個成本尚未納入我們的法規預算估算。請確認：若最終方案是主動控制，HFV 研究的時間與成本是否在你的 Need Criteria 中有所反映？",
                    "agreement": "小組已正確識別被動輔助 vs. 主動控制的技術分岔點，以及感染控制路徑（可重複使用 vs. 一次性）是 Invent 早期必須鎖定的設計限制。",
                    "scope_change": "本輪辯論最重要的法規結論：Need Statement 不應隱含任何技術偏好，必須在 Invent 入口前完成兩件事：(1) TFDA 豁免清單預諮詢；(2) 確認感染控制路徑，否則進入 Invent 後材料選擇和成本結構無法確定。",
                    "agreement_en": "The group correctly identified the passive vs. active fork point and infection control path (reusable vs. disposable) as design constraints to lock before Invent.",
                    "scope_change_en": "The key regulatory conclusion this round: Need Statement must not imply any technology direction. Two items must be completed before Invent entry: (1) TFDA exemption pre-consultation; (2) infection control path determination.",
                },
                "Human-Patient Expert": {
                    "expert_a": "Clinical-Technical Expert",
                    "challenge_a": "你在第一輪提出「動態視野自動維持」作為方案方向之一，但我要從 IEC 62366 的角度正式提出警告：自動化方案存在可預見的 Automation Bias 風險——助理長期依賴自動化後，當感測器失效或鏡面偏移時，操作者因缺乏主動監控習慣而無法即時介入。這是 IEC 62366 定義的 Foreseeable Misuse，必須在 Need Criteria 中加入「任何方案不得增加操作者主動監控負擔」的人因紅線，而不是等到 Invent 後期再處理。",
                    "expert_b": "Regulatory-Business Expert",
                    "challenge_b": "你的法規分析提到 IEC 62366 HFV 的成本，但你的設備分類評估沒有討論「使用者族群」的定義——FDA 和 TFDA 的 HFV 要求中，使用者族群至少需要分開評估牙醫師、牙醫助理、以及作為被動接受者的高齡患者三個群體，且每個族群的 Use Error 類型不同。你的法規預算估算是否已將三族群 HFV 的成本分別納入？另外，你說目標市場應縮窄到高自費診所，但這違反了 Need Criteria 的健康公平性原則——請給出你說「市場規模更保守」的具體數字依據，不能只是方向性判斷。",
                    "agreement": "小組已正確識別 IC-1 的物理根因（三工競爭雙手），以及高齡患者 TMJ 耐受度下降和認知配合度降低作為加重因素。",
                    "scope_change": "本輪人因紅線正式確立，應直接寫入 Need Criteria 的 No-Go Boundaries：(1) 不得增加操作者主動監控任務；(2) 不得增加患者口腔內物理佔用或不適感。這兩條是任何 Invent 方案的硬性排除條件。",
                    "agreement_en": "The group correctly identified the physical root cause of IC-1 (three-task competing for two hands) and elderly patient TMJ tolerance reduction as an aggravating factor.",
                    "scope_change_en": "Two human factors red lines are formally established this round and must be written into Need Criteria No-Go Boundaries: (1) must not increase operator's active monitoring load; (2) must not increase patient's intraoral crowding or discomfort.",
                },
            }

            data = challenge_data.get(role)
            if not data:
                data = {
                    "expert_a": "Clinical-Technical Expert",
                    "challenge_a": "臨床嚴重度、頻率與工程限制仍缺乏直接量測，不能直接視為已成立事實。",
                    "expert_b": "Regulatory-Business Expert",
                    "challenge_b": "市場、法規與採用主張尚未有證據來源，必須標記為待驗證假設。",
                    "agreement": "小組已正確把焦點放在 IC-1：助理多工操作限制。",
                    "scope_change": "Need Statement 應保持 solution-free，鎖定操作中斷與視野維持問題，不指定特定器材。",
                    "agreement_en": "The group correctly focused on IC-1: assistant multitasking limits.",
                    "scope_change_en": "Need Statement should remain solution-free, targeting operational interruptions and visibility maintenance.",
                }

            if cjk_output:
                return (
                    f"### {role}｜交叉挑戰\n\n"
                    f"**挑戰 {data['expert_a']}：** {data['challenge_a']}\n\n"
                    f"**挑戰 {data['expert_b']}：** {data['challenge_b']}\n\n"
                    f"**我認同的部分：** {data['agreement']}\n\n"
                    f"**這輪辯論改變了什麼（對需求範圍的影響）：** {data['scope_change']}"
                )
            return (
                f"### {role}｜Cross-Challenge\n\n"
                f"**Challenge {data['expert_a']}:** {data['challenge_a']}\n\n"
                f"**Challenge {data['expert_b']}:** {data['challenge_b']}\n\n"
                f"**What I agree with:** {data['agreement_en']}\n\n"
                f"**What this round changes (impact on Need Statement scope):** {data['scope_change_en']}"
            )

        if "Critique" in phase or "批判" in phase or "證據缺口" in phase:
            return (
                f"### {role}｜交叉批判\n\n"
                f"**批判視角：** {profile['lens']}\n\n"
                "**我會挑戰的地方：**\n"
                "- 第二階段是否把不同候選議題錯誤合併，或過早選定單一 Top Need。\n"
                f"- 從 {profile['lens']} 來看，最需要被挑戰的推論是：{guidance}\n"
                "- 若任何角色提出具體產品、控制方式、裝置或商業模式，應退回 Identify 階段，只保留可驗證的需求條件。\n\n"
                "**我要求補強的證據：**\n"
                f"{bullets(profile['evidence'])}\n"
                "**進入 Need Screening 前的邊界：**\n"
                f"{bullets(profile['criteria'])}"
            )
        return (
            f"### {role}｜專家提醒\n\n"
            f"**專業視角：** {profile['lens']}\n\n"
            f"**我看到的核心問題：** {guidance}\n\n"
            "**我最在意的假設：**\n"
            f"{bullets(profile['assumptions'])}\n"
            "**下一步最該驗證：**\n"
            f"{bullets(profile['evidence'])}\n"
            "**對 Need Statement / Criteria 的提醒：**\n"
            f"{bullets(profile['criteria'])}"
        )

    @staticmethod
    def _fallback_need_statement(proposal: str, case_packet_text: str, cjk_output: bool) -> str:
        packet = EnhancedMedicalPanel._parse_case_packet(case_packet_text)
        if cjk_output:
            return (
                "一種能夠協助牙科醫療團隊在高齡患者複雜根管治療中同步維持水分控制與清晰操作視野，"
                "以達成降低視野模糊造成之操作中斷與治療時間的方法"
            )
        return (
            "A way to help dental teams maintain moisture control and clear operative visibility during "
            "complex root canal treatment in older adults to reduce visibility-related interruptions and procedure time"
        )

    @staticmethod
    def _build_identify_fallback_report(
        proposal: str,
        case_packet_text: str,
        cjk_output: bool,
        mcdm_weights: dict,
        debate_rounds: int,
    ) -> str:
        packet = EnhancedMedicalPanel._parse_case_packet(case_packet_text)
        need_statement = EnhancedMedicalPanel._fallback_need_statement(proposal, case_packet_text, cjk_output)
        if not cjk_output:
            return (
                "### Consolidated Evaluator | Need Screening & Portfolio\n\n"
                f"**Executive Summary:** Based on {debate_rounds} debate rounds, the strongest need candidate is the "
                "workflow conflict between moisture control and visual-field maintenance during complex endodontic treatment in older adults. "
                "The need is plausible but remains evidence-limited until direct workflow data are collected.\n\n"
                f"**Final Solution-Free Need Statement:** {need_statement}\n\n"
                "**MCDM Evaluation of Need Viability**\n\n"
                "| Criterion | Weight | Score | Rationale |\n"
                "| --- | ---: | ---: | --- |\n"
                f"| System Impact | {mcdm_weights.get('System Impact', 0.4):.0%} | 7 | Interruptions may affect precision, chair time, assistant workload, and patient tolerance. |\n"
                f"| Implementability | {mcdm_weights.get('Implementability', 0.25):.0%} | 6 | The workflow target is narrow, but any later solution must fit a small oral workspace and four-handed dentistry. |\n"
                f"| Risk Control | {mcdm_weights.get('Risk Control', 0.2):.0%} | 6 | Lower risk if framed as workflow support; higher risk if later claims include clinical outcome improvement. |\n"
                f"| Innovation | {mcdm_weights.get('Innovation', 0.1):.0%} | 6 | Existing tools may partially address the issue, but the simultaneous-task conflict appears unmet. |\n"
                f"| Cost-Benefit | {mcdm_weights.get('Cost-Benefit', 0.05):.0%} | 7 | Reducing repeated interruptions may improve chair-time efficiency if frequency is confirmed. |\n\n"
                "**Weighted Need Viability Score:** 6.5 / 10 — Proceed with Validation.\n\n"
                "## Need Profile\n"
                f"- Need Statement (solution-free, final): {need_statement}\n"
                f"- Source Observations: {proposal}\n"
                "- Target Population: older adults undergoing complex root canal treatment, especially cases with limited mouth opening, bleeding, or high moisture burden.\n"
                "- Clinical Context & Workflow Moment: canal shaping / cleaning when the dentist and assistant must maintain visibility while controlling saliva, blood, and dryness.\n"
                "- Current Workarounds: rapid tool switching, verbal repositioning, dentist interruption, and manual mirror adjustment.\n"
                "- Core Pain Point: the assistant cannot reliably maintain suction, air drying, and mirror positioning with two hands in a constrained oral workspace.\n"
                "- Key Risks: unverified frequency, possible existing alternatives, and workflow burden if a later solution adds steps.\n"
                "- Critical Unknowns: interruption rate, seconds lost per interruption, error / near-miss linkage, willingness to pay, and usability constraints.\n\n"
                "## Need Screening\n"
                "- Clinical Impact: 3/5, Medium confidence, needs chart / video evidence.\n"
                "- Problem Frequency: 2/5, Low confidence, needs time-motion observation.\n"
                "- Stakeholder Urgency: 4/5, Medium confidence, needs dentist and assistant interviews.\n"
                "- Current Solution Gap: 3/5, Low confidence, needs competitor / workaround review.\n"
                "- Market Potential: 3/5, Low confidence, needs procedure volume and buyer validation.\n"
                "- Technical Feasibility: 3/5, Medium confidence, constrained by oral space and sterilization.\n"
                "- Regulatory / Reimbursement Risk: 3/5, Medium confidence, depends on later solution claims.\n"
                "- Strategic Fit: 4/5, Medium confidence for dental workflow innovation.\n\n"
                "Overall Score: 3.1 / 5\n"
                "Verdict: Needs More Validation\n\n"
                "## Validation Plan\n"
                "- Key Assumptions to Test: interruption frequency; chair-time loss; assistant hand-occupancy conflict; patient tolerance impact; current workaround failure.\n"
                "- Validation Questions: How often does visibility fail? Which task is sacrificed first? Which patients worsen the problem? What current tools fail and why?\n"
                "- Stakeholders to Interview: endodontists, general dentists doing root canal treatment, dental assistants, clinic owners, older adult patients.\n"
                "- Observation Tasks: video-coded time-motion study of 10-20 complex root canal cases.\n"
                "- Data to Collect: interruption count, seconds to restore visibility, number of verbal commands, tool switching events, patient mouth-opening breaks, near-misses.\n"
                "- Success Criteria: at least 30% of complex cases show repeated visibility interruptions and clinicians rate the issue high urgency.\n"
                "- Red Flags: interruptions are rare, solved by training / rubber dam / existing tools, or adding workflow support worsens access or infection control.\n\n"
                "## Need Criteria\n"
                "- Must-Haves: maintain clear field without increasing hand burden; fit four-handed dentistry; sterilizable or disposable path; low training burden.\n"
                "- Nice-to-Haves: measurable reduction in interruptions and chair time; compatible with existing dental units.\n"
                "- Constraints: oral-space limits, infection control, patient comfort, affordability, and moderate regulatory risk.\n"
                "- Success Metrics: >=50% reduction in visibility-related interruptions; visibility restored in <=2 seconds; no increase in assistant task load.\n"
                "- No-Go Boundaries: requires major workflow retraining, raises contamination risk, or only works in high-end clinics.\n\n"
                "## Mentor Review Summary\n"
                "- What Is Strong: specific workflow moment, clear stakeholders, measurable interruptions.\n"
                "- What Is Weak: no field data, no current-alternative benchmark, no buyer validation.\n"
                "- What Must Be Validated Before Brainstorming Solutions: frequency, burden, existing workaround failure, and clinical urgency.\n"
                "- Mentor Recommendation: Return for Validation, then advance to Invent if frequency and urgency are confirmed."
            )
        return (
            "### 整合評估者｜需求篩選報告與需求檔案\n\n"
            f"**執行摘要：** 根據 {debate_rounds} 輪專家辯論，最強候選需求是高齡患者複雜根管治療中，"
            "水分控制與口內清晰視野維持同時發生時造成的工作流衝突。這個需求具備臨床與人因合理性，但目前仍缺乏田野量化資料，應先列為 Needs More Validation。\n\n"
            f"**最終 Solution-Free Need Statement：** {need_statement}\n\n"
            "**MCDM 需求可行性評估**\n\n"
            "| 準則 | 權重 | 分數 | 理由 |\n"
            "| --- | ---: | ---: | --- |\n"
            f"| System Impact | {mcdm_weights.get('System Impact', 0.4):.0%} | 7 | 視野中斷可能影響操作精準度、椅旁時間、助理負荷與高齡患者耐受度。 |\n"
            f"| Implementability | {mcdm_weights.get('Implementability', 0.25):.0%} | 6 | 需求範圍明確，但後續方案必須符合狹小口腔空間與四手牙科流程。 |\n"
            f"| Risk Control | {mcdm_weights.get('Risk Control', 0.2):.0%} | 6 | 若聚焦工作流支援風險較低；若宣稱改善臨床結果，驗證與法規負擔會升高。 |\n"
            f"| Innovation | {mcdm_weights.get('Innovation', 0.1):.0%} | 6 | 既有工具可能部分解決，但同步多工衝突仍像未被充分處理的痛點。 |\n"
            f"| Cost-Benefit | {mcdm_weights.get('Cost-Benefit', 0.05):.0%} | 7 | 若中斷頻率成立，減少中斷可直接改善椅旁效率與團隊負荷。 |\n\n"
            "**Weighted Need Viability Score：** 6.5 / 10 — Proceed with Validation。\n\n"
            "## Need Profile\n"
            f"- Need Statement (solution-free, final): {need_statement}\n"
            f"- Source Observations: {proposal}\n"
            "- Target Population: 接受複雜根管治療的高齡患者，尤其是開口受限、唾液多、滲血或後牙深部操作案例。\n"
            "- Clinical Context & Workflow Moment: 根管 shaping / cleaning 階段，牙醫師需要精準視野，助理同時負責吸唾、吹乾與視野維持。\n"
            "- Current Workarounds: 助理快速切換器械、口頭協調、醫師暫停操作後手動調整、延長治療時間。\n"
            "- Core Pain Point: 助理在狹小口腔空間內無法以雙手穩定完成吸唾、吹乾與反光視野維持三項任務。\n"
            "- Key Risks: 問題頻率未量化、既有替代方案尚未盤點、後續方案可能增加感染控制或訓練負擔。\n"
            "- Critical Unknowns: 中斷次數、每次中斷秒數、near-miss 關聯、採購意願、患者舒適度與可近性。\n\n"
            "## Need Screening\n"
            "- Clinical Impact: 3/5，信心 Medium，需影片與病例資料佐證。\n"
            "- Problem Frequency: 2/5，信心 Low，需 time-motion observation。\n"
            "- Stakeholder Urgency: 4/5，信心 Medium，需牙醫師與助理訪談。\n"
            "- Current Solution Gap: 3/5，信心 Low，需盤點 rubber dam、吸唾配置、反光鏡/固定工具等替代方案。\n"
            "- Market Potential: 3/5，信心 Low，需確認根管治療量、付費者與診所採購動機。\n"
            "- Technical Feasibility: 3/5，信心 Medium，主要受口腔空間、滅菌與人因限制影響。\n"
            "- Regulatory / Reimbursement Risk: 3/5，信心 Medium，取決於後續方案是否做安全/療效宣稱。\n"
            "- Strategic Fit: 4/5，信心 Medium，符合牙科工作流創新與高齡照護需求。\n\n"
            "Overall Score: 3.1 / 5\n"
            "Verdict: Needs More Validation\n\n"
            "## Validation Plan\n"
            "- Key Assumptions to Test: 中斷頻率、椅旁時間損失、助理雙手佔用衝突、患者耐受度影響、現有 workaround 失敗點。\n"
            "- Validation Questions: 視野失效多久發生一次？助理最先犧牲哪個任務？哪些患者情境使問題惡化？現有工具為何不夠？\n"
            "- Stakeholders to Interview: endodontist、執行根管治療的一般牙醫、牙醫助理、診所管理者、高齡患者。\n"
            "- Observation Tasks: 對 10-20 件複雜根管案例做錄影與 time-motion coding。\n"
            "- Data to Collect: 視野中斷次數、恢復秒數、口頭指令次數、器械切換次數、患者開口休息次數、near-miss。\n"
            "- Success Criteria: 至少 30% 複雜案例出現重複視野中斷，且醫師/助理評為高急迫改善項目。\n"
            "- Red Flags: 中斷很少見、訓練或現有工具即可解決、任何流程支援反而增加感染控制或患者不適。\n\n"
            "## Need Criteria\n"
            "- Must-Haves: 不增加助理手部負擔即可維持清晰視野；符合四手牙科；可滅菌或有清楚耗材路徑；低訓練負擔。\n"
            "- Nice-to-Haves: 可量化降低中斷與椅旁時間；相容既有牙科設備。\n"
            "- Constraints: 口腔空間、感染控制、患者舒適度、診所成本、moderate regulatory risk。\n"
            "- Success Metrics: 視野相關中斷降低 >=50%；視野恢復 <=2 秒；不增加助理任務負荷。\n"
            "- No-Go Boundaries: 需要大幅重新訓練、增加污染風險、只適用高端診所或高自費族群。\n\n"
            "## Mentor Review Summary\n"
            "- What Is Strong: 工作流時刻明確、利害關係人清楚、可量測中斷指標明確。\n"
            "- What Is Weak: 缺少田野資料、缺少現有替代方案比較、缺少採購/付費意願驗證。\n"
            "- What Must Be Validated Before Brainstorming Solutions: 發生頻率、負擔大小、現有 workaround 失敗原因、臨床急迫性。\n"
            "- Mentor Recommendation: Return for Validation；若頻率與急迫性成立，再 Advance to Invent。"
        )

    @staticmethod
    def _format_project_context(project_context: dict | None) -> str:
        if not project_context:
            return "N/A"
        lines = []
        labels = {
            "clinical_area": "Clinical Area",
            "care_setting": "Care Setting",
            "target_stakeholders": "Target Stakeholders",
            "team_strengths": "Team Strengths",
            "market_focus": "Market Focus",
            "risk_appetite": "Risk Appetite",
        }
        for key, label in labels.items():
            value = project_context.get(key)
            if value:
                lines.append(f"- {label}: {value}")
        return "\n".join(lines) if lines else "N/A"

    @staticmethod
    def _select_best_need_statement(versions: list, cjk_output: bool) -> str:
        best_statement = ""
        best_score = -1
        for item in versions or []:
            statement = item.get("statement", "") if isinstance(item, dict) else str(item)
            if EnhancedMedicalPanel._looks_like_placeholder_need(statement):
                continue
            quality = EnhancedMedicalPanel._check_need_statement_quality(statement, cjk_output)
            score = sum([
                bool(quality.get("format_ok")),
                bool(quality.get("solution_free")),
                bool(quality.get("has_target_population")),
                bool(quality.get("has_measurable_outcome")),
            ])
            if score >= best_score:
                best_score = score
                best_statement = statement
        return best_statement

    @staticmethod
    def _check_need_statement_quality(statement: str, cjk_output: bool) -> dict:
        text = statement or ""
        solution_terms = [
            "app", "device", "sensor", "dashboard", "AI", "algorithm", "platform",
            "wearable", "software", "robot", "implant", "kit", "tool",
            "應用程式", "裝置", "感測器", "平台", "演算法", "軟體", "機器人", "植入物", "工具",
            "系統", "控制系統", "非接觸式控制"
        ]
        format_ok = bool(re.search(r"\bA way to\b.+\bto\b", text, re.IGNORECASE)) if not cjk_output else (
            "一種" in text and "以達成" in text
        )
        solution_free = not any(term.lower() in text.lower() for term in solution_terms)
        has_population = len(text.split()) >= 8 if not cjk_output else len(text) >= 18
        if cjk_output:
            has_outcome = any(term in text for term in ["降低", "提升", "改善", "預防", "偵測", "達成", "減少", "縮短"])
        else:
            has_outcome = bool(re.search(r"\b(reduce|increase|improve|prevent|detect|achieve)\b", text, re.IGNORECASE))
        return {
            "statement": text,
            "format_ok": format_ok,
            "solution_free": solution_free,
            "has_target_population": has_population,
            "has_measurable_outcome": has_outcome,
            "passed": all([format_ok, solution_free, has_population, has_outcome]),
        }

    @staticmethod
    def _extract_claims_and_gaps(fact_report: str) -> dict:
        claims = []
        evidence_gaps = []
        for line in (fact_report or "").splitlines():
            stripped = line.strip(" -*\t")
            if not stripped:
                continue
            # Skip pure section headings — they end with "：" or ":" with no trailing content
            if stripped.endswith(("：", ":")) and len(stripped) < 35:
                continue
            lower = stripped.lower()
            if any(key in lower for key in ["claim", "主張", "假設"]):
                claims.append(stripped)
            if any(key in lower for key in ["evidence", "pubmed", "fda", "tfda", "cpt", "hcpcs", "patent", "pilot", "證據", "查證", "資料"]):
                evidence_gaps.append(stripped)
        return {"claims": claims[:12], "evidence_gaps": evidence_gaps[:12]}

    @staticmethod
    def _extract_risks(text: str) -> list:
        risks = []
        for line in (text or "").splitlines():
            stripped = line.strip(" -*\t")
            if not stripped:
                continue
            if any(key in stripped.lower() for key in ["risk", "failure", "barrier", "limitation", "風險", "限制", "障礙", "失敗"]):
                risks.append(stripped)
        return risks[:20]

    @staticmethod
    def _extract_options(text: str) -> list:
        options = []
        current = None
        for line in (text or "").splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            is_option = re.match(r"^(?:#{1,4}\s*)?(?:Option|方案)\s*\d*[\.:：\-]?\s*(.+)", stripped, re.IGNORECASE)
            numbered = re.match(r"^\d+[\.)]\s+(.+)", stripped)
            if is_option or (numbered and len(options) < 5):
                if current:
                    options.append(current)
                name = (is_option.group(1) if is_option else numbered.group(1)).strip()
                current = {"name": name, "notes": []}
            elif current:
                current["notes"].append(stripped)
        if current:
            options.append(current)
        return options[:5]

    @staticmethod
    def _extract_mcdm_scores(text: str) -> dict:
        scores = {}
        criteria = ["System Impact", "Implementability", "Risk Control", "Innovation", "Cost-Benefit"]
        aliases = {
            "System Impact": ["system impact", "系統影響"],
            "Implementability": ["implementability", "可實作", "實作"],
            "Risk Control": ["risk control", "風險控制"],
            "Innovation": ["innovation", "創新"],
            "Cost-Benefit": ["cost-benefit", "cost benefit", "成本效益"],
        }
        for criterion in criteria:
            for alias in aliases[criterion]:
                pattern = rf"{re.escape(alias)}[^\d]{{0,30}}(\d+(?:\.\d+)?)\s*(?:/|out of)?\s*10?"
                match = re.search(pattern, text or "", flags=re.IGNORECASE)
                if match:
                    scores[criterion] = min(float(match.group(1)), 10.0)
                    break
        return scores

    @staticmethod
    def _calculate_sensitivity(scores: dict, weights: dict) -> dict:
        if not scores:
            return {}
        normalized = {k: scores.get(k, 0.0) for k in weights}
        base = sum(normalized[k] * weights[k] for k in weights)
        one_at_a_time = {}
        for criterion in weights:
            variants = {}
            for direction, factor in [("minus_15_percent", 0.85), ("plus_15_percent", 1.15)]:
                adjusted = dict(weights)
                adjusted[criterion] = adjusted[criterion] * factor
                total = sum(adjusted.values()) or 1.0
                adjusted = {key: value / total for key, value in adjusted.items()}
                variants[direction] = {
                    "weighted_score": round(sum(normalized[key] * adjusted[key] for key in adjusted), 2),
                    "weights": {key: round(value, 4) for key, value in adjusted.items()},
                }
            one_at_a_time[criterion] = variants
        return {
            "base_weighted_score": round(base, 2),
            "one_at_a_time": one_at_a_time,
            "note": "Each criterion is perturbed by +/-15% independently, then all weights are renormalized before recalculating the weighted score.",
        }

    # ── Debate helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _debate_round_label(round_idx: int, debate_rounds: int, cjk_output: bool) -> str:
        """Return a display label for the given debate round."""
        if round_idx == 1:
            return "第二階段：辯論第一輪｜初始立場" if cjk_output else "Debate Round 1 · Initial Positions"
        elif round_idx == debate_rounds:
            if debate_rounds == 2:
                return "第三階段：辯論第二輪｜交叉挑戰" if cjk_output else "Debate Round 2 · Cross-Challenge"
            return f"第{round_idx}輪辯論｜立場修正與共識" if cjk_output else f"Debate Round {round_idx} · Position Revision & Consensus"
        else:
            return f"第{round_idx}輪辯論｜交叉挑戰" if cjk_output else f"Debate Round {round_idx} · Cross-Challenge"

    @staticmethod
    def _format_prior_round(round_transcript: dict, exclude_role: str = "") -> str:
        """Produce a compact summary of the previous round for use in prompts."""
        lines = []
        for role, content in round_transcript.items():
            if role == exclude_role:
                continue
            # Keep first 350 chars per speaker – enough for challenge prompts
            excerpt = (content or "")[:350].replace("\n", " ").strip()
            if excerpt:
                lines.append(f"**{role}**: {excerpt}…")
        return "\n".join(lines)

    @staticmethod
    def _role_specific_round1_requirements(role: str, cjk_output: bool) -> str:
        if cjk_output:
            requirements = {
                "Clinical-Technical Expert": (
                    "ROLE-SPECIFIC REQUIREMENTS:\n"
                    "- 量化臨床風險路徑：從工作流中斷到患者/治療品質後果。\n"
                    "- 定義至少 3 個可量測工程或工作流指標，例如中斷次數、恢復秒數、手部佔用、視野失效門檻。\n"
                    "- 不提出裝置或方案；只定義需要被驗證的臨床與技術條件。"
                ),
                "Regulatory-Business Expert": (
                    "ROLE-SPECIFIC REQUIREMENTS:\n"
                    "- 必須先判斷這個需求目前比較像 workflow support、passive intraoral accessory、reusable accessory、single-use accessory、active controlled device，並說明哪條路徑風險最低/最高。\n"
                    "- 必須點名感染控制與再處理/拋棄式路徑：reusable 需考慮 cleaning/disinfection/sterilization validation；single-use 需考慮 biocompatibility 與成本。\n"
                    "- 必須評估買單者與使用者是否一致：牙醫、助理、診所老闆、患者誰痛、誰付錢、誰受益。\n"
                    "- 必須列出要先盤點的既有替代方案，例如 rubber dam、high-volume suction、助理站位、鏡面防霧/固定工具；不要只說『需驗證市場』。"
                ),
                "Human-Patient Expert": (
                    "ROLE-SPECIFIC REQUIREMENTS:\n"
                    "- 必須做 work-as-done workflow map：吸唾、吹乾、調鏡、口頭指令、醫師暫停、患者張口疲勞各在何時發生。\n"
                    "- 必須做 CTA：視覺、聽覺、手部 motor output 哪些通道在同一時刻飽和。\n"
                    "- 必須用 Reason error modes 舉例：slip、lapse、mistake、violation 各一個本案情境。\n"
                    "- 必須明確說出患者端限制：高齡患者張口耐受、焦慮、吞嚥/噁心感、口內擁擠感、低資源診所可近性。"
                ),
            }
        else:
            requirements = {
                "Clinical-Technical Expert": (
                    "ROLE-SPECIFIC REQUIREMENTS:\n"
                    "- Quantify the clinical harm pathway from workflow interruption to treatment quality or patient consequence.\n"
                    "- Define at least 3 measurable clinical/technical metrics such as interruption count, seconds to recover visibility, hand occupancy, or visual-field failure threshold.\n"
                    "- Do not propose devices or solutions; define clinical and technical validation conditions only."
                ),
                "Regulatory-Business Expert": (
                    "ROLE-SPECIFIC REQUIREMENTS:\n"
                    "- Classify the current need envelope: workflow support, passive intraoral accessory, reusable accessory, single-use accessory, or active controlled device. State lowest-risk and highest-risk paths.\n"
                    "- Explicitly address infection control and reprocessing/disposable paths.\n"
                    "- Separate user, buyer, payer, and beneficiary incentives.\n"
                    "- Name existing alternatives to benchmark before Invent; do not merely say market validation is needed."
                ),
                "Human-Patient Expert": (
                    "ROLE-SPECIFIC REQUIREMENTS:\n"
                    "- Map work-as-done, including suction, air drying, mirror adjustment, verbal commands, operator pause, and patient fatigue.\n"
                    "- Perform CTA: which visual, auditory, and motor channels are saturated at the same moment.\n"
                    "- Apply Reason's error modes with one case-specific slip, lapse, mistake, and violation scenario.\n"
                    "- State patient-side constraints: older adult mouth-opening tolerance, anxiety, swallowing/gagging, perceived intraoral crowding, and low-resource clinic access."
                ),
            }
        return requirements.get(role, "")

    def _debate_position_prompt(
        self, role, proposal, case_packet_text, needs_brief,
        intake_context, context, lang_instruction, lang_name, cjk_output,
    ) -> str:
        """Round 1 – initial position statement."""
        return (
            f"{lang_instruction}\n\n"
            f"You are the {role}. This is Debate Round 1: Initial Position.\n"
            "Do not introduce your role, operating framework, or reporting protocol. "
            "Do not ask the user to submit a proposal. Respond directly to the clinical observation and case packet.\n\n"
            f"Case Packet:\n{case_packet_text}\n\n"
            f"Clinical Phenomenon Brief:\n{needs_brief}\n\n"
            f"Strategic Focus & Constraints:\n{intake_context}\n\n"
            f"{self._role_specific_round1_requirements(role, cjk_output)}\n\n"
            "State your initial position on this clinical phenomenon from your domain perspective.\n"
            "Include:\n"
            "1. One-sentence domain lens\n"
            "2. Key observations on the issue candidates (reference by Issue ID or short title only)\n"
            "3. Top 2 assumptions that must be validated before a Need Statement is finalised\n"
            "4. Top 2 evidence items needed\n"
            "5. Which issue candidate should be prioritised and why\n\n"
            "Format exactly:\n"
            + (
                f"### {role}｜Round 1 立場\n"
                "**專業視角：** …\n"
                "**主要觀察：** …\n"
                "**必須驗證：**\n- …\n- …\n"
                "**需要的證據：**\n- …\n- …\n"
                "**優先議題建議：** …\n\n"
                if cjk_output else
                f"### {role}｜Round 1 Position\n"
                "**Domain Lens:** …\n"
                "**Key Observations:** …\n"
                "**Assumptions to Validate:**\n- …\n- …\n"
                "**Evidence Needed:**\n- …\n- …\n"
                "**Priority Issue Candidate:** …\n\n"
            )
            + "Constraints: No solutions. No device concepts. Under 400 chars per section; Regulatory and Human Factors sections may use up to 600 chars to capture standards and error-mode detail.\n\n"
            f"Shared state:\n{context}\n\nWrite in {lang_name}."
        )

    def _debate_challenge_prompt(
        self, role, proposal, case_packet_text, prior_round_text,
        context, lang_instruction, lang_name, cjk_output, round_idx,
    ) -> str:
        """Round 2 (or intermediate) – cross-challenge; must name other experts."""
        return (
            f"{lang_instruction}\n\n"
            f"You are the {role}. This is Debate Round {round_idx}: Cross-Challenge.\n"
            "Your job is to critically challenge what OTHER experts said in the previous round. "
            "You MUST explicitly name at least TWO other experts and challenge their specific claims or assumptions.\n\n"
            f"Case Packet (for reference):\n{case_packet_text}\n\n"
            f"What other experts said in the PREVIOUS round:\n{prior_round_text}\n\n"
            "Required output:\n"
            "1. Challenge Expert A (name them): which specific claim do you dispute and why?\n"
            "2. Challenge Expert B (name them): which assumption is unsupported from your perspective?\n"
            "3. What (if anything) do you agree with from the previous round?\n"
            "4. What does this exchange surface that should sharpen the Need Statement scope?\n\n"
            "Format exactly:\n"
            + (
                f"### {role}｜Round {round_idx} 交叉挑戰\n"
                "**挑戰 [Expert A 名稱]：** …\n"
                "**挑戰 [Expert B 名稱]：** …\n"
                "**我認同的部分：** …\n"
                "**這輪辯論改變了什麼（對需求範圍的影響）：** …\n\n"
                if cjk_output else
                f"### {role}｜Round {round_idx} Cross-Challenge\n"
                "**Challenge [Expert A name]:** …\n"
                "**Challenge [Expert B name]:** …\n"
                "**What I agree with:** …\n"
                "**What this round changes (impact on Need Statement scope):** …\n\n"
            )
            + "Constraints: Be specific and cite exact claims. No solutions. Under 400 chars per challenge point; Regulatory and Human Factors challenges may use up to 600 chars when citing specific standards (IEC 62366, ISO 17664, TFDA regulations).\n\n"
            f"Full shared state:\n{context}\n\nWrite in {lang_name}."
        )

    def _debate_revision_prompt(
        self, role, proposal, case_packet_text, all_prior_text,
        context, lang_instruction, lang_name, cjk_output, round_idx,
    ) -> str:
        """Final round (≥3) – respond to challenges and revise position."""
        return (
            f"{lang_instruction}\n\n"
            f"You are the {role}. This is Debate Round {round_idx}: Position Revision.\n"
            "Review all challenges directed at you or your domain in previous rounds. "
            "Respond directly to those challenges and state your REVISED final position.\n\n"
            f"Case Packet:\n{case_packet_text}\n\n"
            f"Full debate so far (all prior rounds):\n{all_prior_text}\n\n"
            "Required output:\n"
            "1. Which challenges from other experts do you accept as valid and why?\n"
            "2. Which challenges do you reject and what is your counter-argument?\n"
            "3. Your revised final position: what is the single most important need dimension to investigate?\n"
            "4. The one evidence gap that must be closed before the Need Statement is finalised.\n\n"
            "Format exactly:\n"
            + (
                f"### {role}｜Round {round_idx} 修正立場\n"
                "**接受的挑戰（及理由）：** …\n"
                "**拒絕的挑戰（及反論）：** …\n"
                "**修正後的最終立場：** …\n"
                "**最關鍵的證據缺口：** …\n\n"
                if cjk_output else
                f"### {role}｜Round {round_idx} Revised Position\n"
                "**Challenges accepted (and why):** …\n"
                "**Challenges rejected (counter-argument):** …\n"
                "**Revised final position:** …\n"
                "**Most critical evidence gap:** …\n\n"
            )
            + "Constraints: Be concrete. Reference challengers by name. No solutions.\n\n"
            f"Write in {lang_name}."
        )

    # ── End debate helpers ───────────────────────────────────────────────────

    # ── Invent phase helpers ─────────────────────────────────────────────────

    def _invent_brainstorm_prompt(
        self, role, proposal, final_need_statement, case_packet_text,
        context, lang_instruction, lang_name, cjk_output,
    ) -> str:
        """Invent Phase Round 1 – divergent brainstorm: each expert proposes 1-2 solution concepts."""
        if cjk_output:
            fmt = (
                f"### {role}｜Invent Brainstorm\n"
                "**方案概念 1 [短名稱]：**\n"
                "- 核心機制：[如何解決這個需求]\n"
                "- 為什麼從我的領域出發：[領域專屬的理由]\n"
                "- 關鍵未知數：[要成立必須為真的假設]\n\n"
                "**方案概念 2 [短名稱]（選填）：**\n"
                "- 核心機制：…\n"
                "- 為什麼從我的領域出發：…\n"
                "- 關鍵未知數：…\n"
            )
        else:
            fmt = (
                f"### {role}｜Invent Brainstorm\n"
                "**Solution Concept 1 [Short Name]:**\n"
                "- Core mechanism: [how it addresses the need]\n"
                "- Domain rationale: [why this from my expertise]\n"
                "- Key unknown: [assumption that must hold for this to work]\n\n"
                "**Solution Concept 2 [Short Name] (optional):**\n"
                "- Core mechanism: …\n"
                "- Domain rationale: …\n"
                "- Key unknown: …\n"
            )
        return (
            f"{lang_instruction}\n\n"
            f"You are the {role}. This is the **Invent Phase – Brainstorm Round**.\n"
            "The Identify phase has produced a validated Need Statement. "
            "Your job now is to propose 1–2 SOLUTION CONCEPTS from your domain perspective.\n\n"
            "Rules for this round:\n"
            "- Be CREATIVE and DIVERGENT — do not self-censor.\n"
            "- Do NOT evaluate other experts' concepts yet.\n"
            "- Solutions must directly address the Need Statement.\n"
            "- Keep each concept description concise (≤150 words).\n\n"
            f"Validated Need Statement:\n{final_need_statement}\n\n"
            f"Case Packet (for context):\n{case_packet_text}\n\n"
            f"Required format:\n{fmt}\n"
            f"Write in {lang_name}."
        )

    def _invent_solution_critique_prompt(
        self, role, proposal, brainstorm_summary, final_need_statement,
        context, lang_instruction, lang_name, cjk_output,
    ) -> str:
        """Invent Phase – initial solution critique: each expert evaluates ALL brainstorm concepts."""
        if cjk_output:
            fmt = (
                f"### {role}｜方案批判\n"
                "**我支持：** [方案名稱] — [具體理由]\n"
                "**我反對：** [方案名稱] — [具體理由]\n"
                "**修改建議（讓最差的方案變可行）：** …\n"
                "**從我領域看所有方案最大的跨域風險：** …\n"
            )
        else:
            fmt = (
                f"### {role}｜Solution Critique\n"
                "**I support:** [Concept Name] — [specific reason]\n"
                "**I oppose:** [Concept Name] — [specific reason]\n"
                "**Modification to make the weakest concept viable:** …\n"
                "**Biggest cross-domain risk across ALL concepts (from my view):** …\n"
            )
        return (
            f"{lang_instruction}\n\n"
            f"You are the {role}. This is the **Invent Phase – Solution Critique Round**.\n"
            "Evaluate ALL proposed solution concepts from your domain perspective. "
            "Be specific — name concepts by their short title.\n\n"
            f"Need Statement (must be addressed):\n{final_need_statement}\n\n"
            f"All proposed solution concepts from Brainstorm:\n{brainstorm_summary}\n\n"
            "Required output:\n"
            "1. Which concept(s) you support and why (domain-specific)\n"
            "2. Which concept(s) you oppose and why (cite specific risk or gap)\n"
            "3. What modification would make your least favourite concept viable\n"
            "4. The single biggest risk across ALL concepts from your domain view\n\n"
            f"Required format:\n{fmt}\n"
            f"Write in {lang_name}."
        )

    def _invent_solution_challenge_prompt(
        self, role, proposal, prior_critique_summary, final_need_statement,
        context, lang_instruction, lang_name, cjk_output, round_idx,
    ) -> str:
        """Invent Phase – cross-challenge on solutions: must name ≥2 other experts."""
        if cjk_output:
            fmt = (
                f"### {role}｜方案辯論 Round {round_idx}\n"
                "**回應 [Expert A 名稱] 對 [方案名稱] 的批判：** [同意/不同意 + 具體反論]\n"
                "**回應 [Expert B 名稱] 對 [方案名稱] 的批判：** [同意/不同意 + 具體反論]\n"
                "**我目前支持的最佳方案（有無改變）：** …\n"
                "**要讓這個方案勝出還需要解決什麼：** …\n"
            )
        else:
            fmt = (
                f"### {role}｜Solution Debate Round {round_idx}\n"
                "**Response to [Expert A] on [Concept]:** [agree/disagree + counter-argument]\n"
                "**Response to [Expert B] on [Concept]:** [agree/disagree + counter-argument]\n"
                "**My current top candidate (changed?):** …\n"
                "**What must be resolved for this concept to win:** …\n"
            )
        return (
            f"{lang_instruction}\n\n"
            f"You are the {role}. This is **Invent Phase Solution Debate Round {round_idx}**.\n"
            "Read what other experts said in the previous critique round. "
            "Respond directly to their specific points — name at least TWO other experts.\n\n"
            f"Need Statement:\n{final_need_statement}\n\n"
            f"Previous round critiques (summarised):\n{prior_critique_summary}\n\n"
            "Required output:\n"
            "1. Respond to Expert A by name: agree or challenge their critique of a specific concept\n"
            "2. Respond to Expert B by name: agree or challenge their critique\n"
            "3. State whether your preferred concept has changed and why\n"
            "4. What single gap must be closed for the strongest concept to move forward\n\n"
            f"Required format:\n{fmt}\n"
            f"Write in {lang_name}."
        )

    # ── End Invent phase helpers ─────────────────────────────────────────────

    def run_discussion(
        self,
        proposal: str,
        callback=None,
        status_callback=None,
        mcdm_weights=None,
        identify_only=True,
        project_context=None,
        known_constraints="",
        evidence_available="",
        debate_rounds: int = 2,
        invent_rounds: int = 2,
    ):
        def notify(role, message):
            if callback:
                callback(role, message)
            else:
                print(f"\n[{role}]:")
                print(message)
                print("-" * 30)

        logger.info(f"--- Discussing Proposal: {proposal} ---")

        for agent in self.all_agents:
            agent.reset()

        lang_instruction = self._language_instruction(proposal)
        cjk_output = self._uses_cjk(proposal)
        lang_name = "Traditional Chinese" if cjk_output else "English"
        project_context = project_context or {}
        project_context_text = self._format_project_context(project_context)
        intake_context = (
            f"Strategic Focus:\n{project_context_text}\n\n"
            f"Known Constraints:\n{known_constraints or 'N/A'}\n\n"
            f"Evidence Available:\n{evidence_available or 'N/A'}"
        )
        state = DiscussionState(
            observation=proposal,
            language=lang_name,
            project_context=project_context,
            known_constraints=known_constraints,
            evidence_available=evidence_available,
        )
        if mcdm_weights:
            total_weight = sum(float(value) for value in mcdm_weights.values()) or 1.0
            state.mcdm_weights = {
                key: float(value) / total_weight
                for key, value in mcdm_weights.items()
            }

        case_extraction_label = "臨床特徵萃取" if cjk_output else "Clinical Feature Extraction"
        needs_brief_label = "第一階段：臨床現象分析" if cjk_output else "Phase 1: Clinical Phenomenon Analysis"
        position_label = "第二階段：專家立場圓桌" if cjk_output else "Phase 2: Expert Position Roundtable"
        critique_label = "第三階段：交叉批判與證據缺口" if cjk_output else "Phase 3: Critique & Evidence Gaps"
        option_label = "第四階段：方案形成" if cjk_output else "Phase 4: Option Formation"
        review_label = "第五階段：定向複審" if cjk_output else "Phase 5: Targeted Review"
        rerate_label = (
            "第四階段：需求篩選與檔案" if cjk_output and identify_only else
            "Phase 4: Need Screening & Portfolio" if identify_only else
            "第六階段：MCDM 再評分" if cjk_output else "Phase 5: MCDM Re-rate"
        )
        identify_label = (
            "第四階段：需求篩選與檔案" if cjk_output and identify_only else
            "Phase 4: Need Screening & Portfolio" if identify_only else
            "第七階段：Identify Portfolio" if cjk_output else "Phase 7: Identify Portfolio"
        )
        final_report_label = "最終評估報告" if cjk_output else "Final Evaluation Report"
        identify_report_label = "STB Identify 需求檔案" if cjk_output else "STB Identify Portfolio"
        discovery_label = "討論紀錄" if cjk_output else "Discussion History"
        quality_label = "Need Statement 品質檢查" if cjk_output else "Need Statement Quality Check"

        intake_role = self._display_role("Intake Analyzer", proposal)
        clin_tech_role = self._display_role("Clinical-Technical Expert", proposal)
        reg_biz_role = self._display_role("Regulatory-Business Expert", proposal)
        human_patient_role = self._display_role("Human-Patient Expert", proposal)
        critical_role = self._display_role("Critical Review Agent", proposal)
        option_role = self._display_role("Option Formation Agent", proposal)
        evaluator_role = self._display_role("Consolidated Evaluator", proposal)

        # Clamp debate_rounds to a sensible range
        debate_rounds = max(2, min(int(debate_rounds), 4))

        debate_roles = [
            "Clinical-Technical Expert",
            "Regulatory-Business Expert",
            "Human-Patient Expert",
        ]

        # Build agenda: 7-agent structure
        agenda = [
            {"phase": needs_brief_label, "role": intake_role, "action": "正在萃取案例與現象分析" if cjk_output else "Extracting case packet & phenomenon analysis"},
        ]
        for round_idx in range(1, debate_rounds + 1):
            rlabel = EnhancedMedicalPanel._debate_round_label(round_idx, debate_rounds, cjk_output)
            for role in debate_roles:
                display_role = self._display_role(role, proposal)
                if round_idx == 1:
                    action = "正在提出初始立場" if cjk_output else "Stating initial position"
                elif round_idx == debate_rounds and debate_rounds > 2:
                    action = "正在修正立場" if cjk_output else "Revising position"
                else:
                    action = "正在交叉挑戰" if cjk_output else "Cross-challenging"
                agenda.append({"phase": rlabel, "role": display_role, "action": action})
            agenda.append({"phase": rlabel, "role": critical_role, "action": f"正在批判審查第{round_idx}輪" if cjk_output else f"Critical review of Round {round_idx}"})
        # Identify convergence (always present)
        agenda.append({"phase": rerate_label, "role": evaluator_role, "action": "正在定義需求、篩選與建立檔案" if cjk_output else "Need screening, MCDM & portfolio"})
        if not identify_only:
            # Invent Phase labels
            invent_brainstorm_label = "Invent 第一階段：方案發散" if cjk_output else "Invent Phase 1 · Brainstorm"
            invent_option_label     = "Invent 第二階段：方案整合" if cjk_output else "Invent Phase 2 · Option Formation"
            invent_critique_label   = "Invent 第三階段：方案辯論" if cjk_output else "Invent Phase 3 · Solution Debate"
            invent_mcdm_label       = "Invent 第四階段：MCDM 收斂" if cjk_output else "Invent Phase 4 · MCDM Convergence"
            invent_rounds_clamped   = max(2, min(int(invent_rounds), 4))
            # Brainstorm: 3 experts
            for role in debate_roles:
                agenda.append({"phase": invent_brainstorm_label, "role": self._display_role(role, proposal),
                                "action": "正在提出方案概念" if cjk_output else "Proposing solution concepts"})
            # Option formation
            agenda.append({"phase": invent_option_label, "role": option_role,
                            "action": "正在整合方案選項" if cjk_output else "Consolidating options"})
            # Multi-round solution debate
            for round_idx in range(1, invent_rounds_clamped + 1):
                sol_rlabel = (
                    f"Invent 方案辯論 Round {round_idx}｜{'初始批判' if round_idx == 1 else '交叉挑戰'}"
                    if cjk_output else
                    f"Invent Solution Debate R{round_idx} · {'Critique' if round_idx == 1 else 'Cross-Challenge'}"
                )
                for role in debate_roles:
                    agenda.append({"phase": sol_rlabel, "role": self._display_role(role, proposal),
                                   "action": "正在批判方案" if round_idx == 1 else "正在交叉挑戰方案"
                                   if cjk_output else ("Critiquing solutions" if round_idx == 1 else "Cross-challenging solutions")})
                agenda.append({"phase": sol_rlabel, "role": critical_role,
                               "action": f"批判審查方案辯論第{round_idx}輪" if cjk_output else f"Critical review of solution debate R{round_idx}"})
            # MCDM convergence
            agenda.append({"phase": invent_mcdm_label, "role": evaluator_role,
                           "action": "正在進行 MCDM 收斂評分" if cjk_output else "Running MCDM convergence scoring"})

        step_index = 0

        def emit_status():
            nonlocal step_index
            if step_index >= len(agenda):
                return
            if status_callback:
                current_step = agenda[step_index]
                next_step = agenda[step_index + 1] if step_index + 1 < len(agenda) else None
                status_callback({
                    "step": step_index + 1,
                    "total": len(agenda),
                    "phase": current_step["phase"],
                    "role": current_step["role"],
                    "action": current_step["action"],
                    "next_role": next_step["role"] if next_step else None,
                    "next_phase": next_step["phase"] if next_step else None,
                    "agenda": agenda,
                    "done": False,
                })
            step_index += 1

        def ask_and_record(agent, role, phase, prompt, topic_guard=False, retry_prompt=None, fallback_content=None):
            canonical_role = self.agent_role_map.get(agent, role)
            emit_status()
            response = self._ask_language_checked(agent, prompt, proposal, cjk_output).msg
            content = response.content if response else "(Analysis Interrupted)"
            is_phase3_critique = "Critique" in phase or "批判" in phase or "證據缺口" in phase
            if topic_guard and (
                self._looks_like_missing_input_response(content)
                or (
                    not self._is_topic_aligned(proposal, content)
                    and not (is_phase3_critique and self._looks_like_phase2_critique(content))
                )
            ):
                repair_prompt = retry_prompt or (
                    f"{lang_instruction}\n\n"
                    "Your previous response was not grounded in the provided clinical observation. "
                    "Do not ask for more input. Do not provide examples from another condition. "
                    "Use only the clinical observation and shared state below.\n\n"
                    f"Clinical observation:\n{proposal}\n\n"
                    f"Shared state:\n{prompt[-6000:]}\n\n"
                    f"Write in {lang_name}."
                )
                retry_response = self._ask_language_checked(agent, repair_prompt, proposal, cjk_output)
                if retry_response and retry_response.msg:
                    retry_content = retry_response.msg.content
                    retry_ok = (
                        not self._looks_like_missing_input_response(retry_content)
                        and (
                            self._is_topic_aligned(proposal, retry_content)
                            or (is_phase3_critique and self._looks_like_phase2_critique(retry_content))
                        )
                    )
                    if retry_ok:
                        content = retry_content
            if topic_guard and (
                self._looks_like_missing_input_response(content)
                or (
                    not self._is_topic_aligned(proposal, content)
                    and not (is_phase3_critique and self._looks_like_phase2_critique(content))
                )
            ):
                content = fallback_content or self._case_specific_fallback_response(
                    canonical_role,
                    phase,
                    proposal,
                    cjk_output,
                    case_packet_text=state.case_packet,
                )
            if phase in {position_label, critique_label} or "立場" in phase or "批判" in phase:
                content = self._remove_repeated_case_blocks(content)
            notify(role, content)
            broadcast_agent = getattr(self, self.role_to_agent_attr.get(canonical_role, ""), agent)
            self._broadcast_message(broadcast_agent, content)
            state.add_message(phase, role, content)
            state.risks.extend(self._extract_risks(content))
            statement = self._extract_need_statement(content)
            if statement:
                state.add_need_statement_version(phase, role, statement)
            return content

        # ── Step 1: Intake Analyzer (Case Packet + Phenomenon Brief in one call) ──
        intake_prompt = (
            f"{lang_instruction}\n\n"
            f"{intake_context}\n\n"
            f"Raw clinical observation:\n{proposal}\n\n"
            "Perform BOTH tasks (A: Case Packet Extraction, B: Clinical Phenomenon Analysis Brief) in one response. "
            "Do not formulate a Need Statement. Do not propose solutions."
        )
        intake_output = ask_and_record(self.intake_analyzer, intake_role, needs_brief_label, intake_prompt)
        # Treat the combined output as both the case packet and the needs brief
        state.case_packet = intake_output
        state.needs_brief = intake_output
        case_packet_text = intake_output
        needs_brief = intake_output
        state.specified_need = ""  # No need statement defined yet

        context = f"Observation:\n{proposal}\n\n[STB Identify Intake]\n{intake_context}\n\n[{needs_brief_label}]\n{intake_output}"

        # ── Multi-round debate ──────────────────────────────────────────────
        # round_transcripts[i] = {role: content} for round i+1
        round_transcripts: list[dict] = []

        for round_idx in range(1, debate_rounds + 1):
            is_first = round_idx == 1
            is_last  = round_idx == debate_rounds
            rlabel   = EnhancedMedicalPanel._debate_round_label(round_idx, debate_rounds, cjk_output)
            round_transcript: dict = {}

            for role in debate_roles:
                agent        = self.expert_map[role]
                display_role = self._display_role(role, proposal)

                if is_first:
                    prompt = self._debate_position_prompt(
                        role, proposal, case_packet_text, needs_brief,
                        intake_context, context, lang_instruction, lang_name, cjk_output,
                    )
                    retry_focus = (
                        "Give a case-specific initial position on the clinical phenomenon "
                        "from your domain perspective. Include assumptions, evidence needed, "
                        "and issue candidate prioritisation."
                    )
                    retry_prompt = self._grounded_round_retry_prompt(
                        proposal, lang_instruction, lang_name, role,
                        f"Debate Round {round_idx}: Initial Position",
                        retry_focus, context,
                    )
                    fallback = self._case_specific_fallback_response(
                        role, rlabel, proposal, cjk_output, case_packet_text=case_packet_text,
                    )
                elif is_last and debate_rounds >= 3:
                    # Final round: revision / consensus
                    all_prior = "\n\n".join(
                        f"=== Round {i + 1} ===\n"
                        + EnhancedMedicalPanel._format_prior_round(rt)
                        for i, rt in enumerate(round_transcripts)
                    )
                    prompt = self._debate_revision_prompt(
                        role, proposal, case_packet_text, all_prior,
                        context, lang_instruction, lang_name, cjk_output, round_idx,
                    )
                    retry_focus = (
                        "Respond to challenges directed at you from previous rounds "
                        "and state your revised final position with a key evidence gap."
                    )
                    retry_prompt = self._grounded_round_retry_prompt(
                        proposal, lang_instruction, lang_name, role,
                        f"Debate Round {round_idx}: Position Revision",
                        retry_focus, context,
                    )
                    fallback = self._case_specific_fallback_response(
                        role, rlabel, proposal, cjk_output, case_packet_text=case_packet_text,
                    )
                else:
                    # Cross-challenge round
                    prior_round_text = EnhancedMedicalPanel._format_prior_round(
                        round_transcripts[-1], exclude_role=role,
                    )
                    prompt = self._debate_challenge_prompt(
                        role, proposal, case_packet_text, prior_round_text,
                        context, lang_instruction, lang_name, cjk_output, round_idx,
                    )
                    retry_focus = (
                        "Challenge at least two other experts by name from the previous round "
                        "with specific critiques of their claims or assumptions."
                    )
                    retry_prompt = self._grounded_round_retry_prompt(
                        proposal, lang_instruction, lang_name, role,
                        f"Debate Round {round_idx}: Cross-Challenge",
                        retry_focus, context,
                    )
                    fallback = self._case_specific_fallback_response(
                        role, rlabel, proposal, cjk_output, case_packet_text=case_packet_text,
                    )

                content = ask_and_record(
                    agent, display_role, rlabel, prompt,
                    topic_guard=True, retry_prompt=retry_prompt, fallback_content=fallback,
                )
                round_transcript[role] = content
                context += f"\n\n[{rlabel} | {role}]\n{content}"

            round_transcripts.append(round_transcript)

            # ── Per-round Critical Review (replaces Devil's Advocate + Fact Checker) ──
            self.critical_reviewer.reset()
            prev_summary = EnhancedMedicalPanel._format_prior_round(round_transcript)
            critical_prompt = (
                f"{lang_instruction}\n\n"
                f"You are the Critical Review Agent. This is the review after Debate Round {round_idx}.\n"
                "Do NOT ask for more input — the full debate context is already included in this message.\n\n"
                "Perform all three review functions (Devil's Advocate, Fact Checker, Bias Detector) "
                "in your structured response. Ground every point in the clinical observation and the round transcript below.\n"
                "Do not write generic audit language. You must quote or paraphrase at least two concrete claims from the round, "
                "name the issue candidate or workflow moment they affect, and state the exact data needed to accept or reject each claim.\n\n"
                "Required format:\n"
                + (
                    f"### 批判審查代理人｜第 {round_idx} 輪審查\n"
                    "**Part A – Devil's Advocate：** [本案最可能失敗的情境；必須點名 workflow moment / issue candidate]\n\n"
                    "**Part B – Fact Checker：**\n"
                    "- Claim 1: [具體主張] → Status: [working assumption / unsupported / overclaim] → Needed evidence: [具體資料來源]\n"
                    "- Claim 2: [具體主張] → Status: [working assumption / unsupported / overclaim] → Needed evidence: [具體資料來源]\n\n"
                    "**Part C – Bias Detector：** [指出是否有 solution anchoring、availability、optimism 或 scope bias；若有，重寫 solution-free 邊界]\n\n"
                    if cjk_output else
                    f"### Critical Review Agent | Round {round_idx} Review\n"
                    "**Part A – Devil's Advocate:** [most likely failure scenario, naming workflow moment / issue candidate]\n\n"
                    "**Part B – Fact Checker:**\n"
                    "- Claim 1: [specific claim] → Status: [working assumption / unsupported / overclaim] → Needed evidence: [specific source]\n"
                    "- Claim 2: [specific claim] → Status: [working assumption / unsupported / overclaim] → Needed evidence: [specific source]\n\n"
                    "**Part C – Bias Detector:** [identify solution anchoring, availability, optimism, or scope bias; rewrite solution-free boundary if needed]\n\n"
                )
                + f"Clinical observation:\n{proposal}\n\n"
                f"Round {round_idx} transcript:\n{prev_summary}\n\n"
                f"Full shared state:\n{context[-8000:]}\n\n"
                f"Write in {lang_name}."
            )
            critical_fallback = (
                "### " + (f"批判審查代理人｜第 {round_idx} 輪審查" if cjk_output else f"Critical Review Agent | Round {round_idx} Review") + "\n\n"
                + ("**Part A – Devil's Advocate:** 本輪最危險的集體假設是高齡患者複雜根管治療中的視野中斷已被證明頻繁且嚴重；但目前仍缺乏 time-motion 影片、每例中斷次數、恢復秒數與患者張口疲勞資料。也不能排除 rubber dam、吸引配置、助理站位、訓練或現有反光鏡工具已能解決大部分問題。\n\n"
                   "**Part B – Fact Checker:** 需要查證的主張包括：複雜根管治療視野中斷頻率、視野中斷與穿孔/器械折斷的關聯、診所願付價格、既有隔離/吸引/固定工具的不足、任何法規分類或生物相容性要求。\n\n"
                   "**Part C – Bias Detector:** 偵測到 solution anchoring 風險——團隊可能過早跳到固定鏡、整合吸唾吹風或自動調鏡。Identify 階段應維持在「同步水分控制與清晰操作視野」的 solution-free 需求。"
                   if cjk_output else
                   "**Part A – Devil's Advocate:** The most dangerous shared assumption is that visibility interruptions during complex root canal treatment in older adults are already proven frequent and severe; field quantification is still missing.\n\n"
                   "**Part B – Fact Checker:** Verify interruption frequency, seconds lost, patient fatigue, existing isolation/suction/mirror alternatives, willingness to pay, and any regulatory or biocompatibility claims.\n\n"
                   "**Part C – Bias Detector:** Solution anchoring risk detected: the team may jump too quickly to mirror fixation, integrated suction/air, or automated adjustment. Keep the need solution-free."
                )
            )
            critical_report = ask_and_record(
                self.critical_reviewer, critical_role, rlabel, critical_prompt,
                topic_guard=True, fallback_content=critical_fallback,
            )
            state.devil_challenge = critical_report  # store in devil_challenge for compatibility
            state.bias_review = critical_report      # store in bias_review for compatibility
            # Extract fact-check data from the critical review
            extracted = self._extract_claims_and_gaps(critical_report)
            state.claims.extend({"phase": rlabel, "source_role": "Critical Review Agent", "claim": item} for item in extracted["claims"])
            state.evidence_gaps.extend({"phase": rlabel, "source_role": "Critical Review Agent", "gap": item} for item in extracted["evidence_gaps"])
            grounding_targets = extracted["claims"][:2] or extracted["evidence_gaps"][:2]
            for target in grounding_targets:
                grounded = self.evidence_grounder.ground_claim(target)
                grounded.update({"phase": rlabel, "source_role": "Critical Review Agent"})
                state.evidence_grounding.append(grounded)
            context += f"\n\n[{rlabel} | {critical_role}]\n{critical_report}"

        evidence_summary_label = "證據查詢摘要" if cjk_output else "Evidence Grounding Summary"
        evidence_summary = self.evidence_grounder.summarize_grounding(state.evidence_grounding)
        context += f"\n\n[{evidence_summary_label}]\n{evidence_summary}"

        # ── Identify Convergence (always runs) ── Evaluator now handles MCDM + Portfolio ──
        self.evaluator.reset()
        identify_eval_prompt = (
            f"{lang_instruction}\n\n"
            "TASK: Synthesize the complete expert debate transcript below into a need-screening report AND "
            "a complete STB Identify Portfolio. "
            "Do NOT ask for more input — the full debate context is already included in this message. "
            "Begin your analysis immediately.\n\n"
            "You are the Consolidated Evaluator for the STB Biodesign Identify phase. "
            "Do not generate product concepts or implementation options. "
            "Complete BOTH Part A (Need Synthesis & MCDM) and Part B (STB Identify Portfolio).\n"
            f"Use these screening weights: "
            f"System Impact {state.mcdm_weights['System Impact']:.0%}, "
            f"Implementability {state.mcdm_weights['Implementability']:.0%}, "
            f"Risk Control {state.mcdm_weights['Risk Control']:.0%}, "
            f"Innovation {state.mcdm_weights['Innovation']:.0%}, "
            f"Cost-Benefit {state.mcdm_weights['Cost-Benefit']:.0%}.\n"
            "If multiple issue candidates exist, compare and select the strongest Top Need.\n"
            "Need Statement format: 'A way to [verb] [population] to achieve [measurable outcome]' "
            "or '一種能夠[動詞][目標族群]以達成[可衡量結果]的方法'.\n"
            f"Write all visible headings and response in {lang_name}.\n\n"
            f"Evidence Grounding Summary:\n{self.evidence_grounder.summarize_grounding(state.evidence_grounding)}\n\n"
            f"=== FULL DEBATE TRANSCRIPT (synthesize this) ===\n{context}\n=== END OF TRANSCRIPT ==="
        )
        identify_eval_fallback = (
            self._build_identify_fallback_report(
                proposal,
                case_packet_text,
                cjk_output,
                state.mcdm_weights,
                debate_rounds,
            )
        )
        final_report = ask_and_record(
            self.evaluator, evaluator_role, rerate_label, identify_eval_prompt,
            topic_guard=True, fallback_content=identify_eval_fallback,
        )
        state.final_report = final_report
        extracted_final_need = self._extract_need_statement(final_report)
        extracted_quality = self._check_need_statement_quality(extracted_final_need, cjk_output)
        if extracted_quality.get("passed"):
            state.final_need_statement = extracted_final_need
        else:
            state.final_need_statement = self._select_best_need_statement(state.need_statement_versions, cjk_output) or extracted_final_need
        if not self._check_need_statement_quality(state.final_need_statement, cjk_output).get("passed"):
            state.final_need_statement = self._fallback_need_statement(proposal, case_packet_text, cjk_output)
        if (
            not self._extract_markdown_section(final_report, ["need profile", "需求檔案", "需求輪廓", "需求概況"])
            or "Need Statement: 待驗證" in final_report
            or "Need Statement: Pending validation" in final_report
        ):
            final_report = identify_eval_fallback
            state.final_report = final_report
        state.add_need_statement_version(rerate_label, evaluator_role, state.final_need_statement)
        state.need_statement_quality = self._check_need_statement_quality(state.final_need_statement, cjk_output)
        id_scores = self._extract_mcdm_scores(final_report)
        if id_scores:
            state.mcdm_scores["identify_screening"] = id_scores
            state.sensitivity_analysis = self._calculate_sensitivity(id_scores, state.mcdm_weights)
        # Extract portfolio sections from the combined evaluator output
        state.identify_portfolio = final_report
        state.need_profile = self._extract_markdown_section(final_report, ["need profile", "需求檔案", "需求輪廓", "需求概況"])
        state.screening_result = self._extract_markdown_section(final_report, ["need screening", "需求篩選", "screening"])
        state.validation_plan = self._extract_markdown_section(final_report, ["validation plan", "驗證計畫", "驗證規劃"])
        state.need_criteria = self._extract_markdown_section(final_report, ["need criteria", "需求準則", "準則"])

        if not identify_only:
            # ── Invent Phase ─────────────────────────────────────────────────
            invent_rounds_clamped = max(2, min(int(invent_rounds), 4))
            invent_brainstorm_label = "Invent 第一階段：方案發散" if cjk_output else "Invent Phase 1 · Brainstorm"
            invent_option_label     = "Invent 第二階段：方案整合" if cjk_output else "Invent Phase 2 · Option Formation"
            invent_mcdm_label       = "Invent 第四階段：MCDM 收斂" if cjk_output else "Invent Phase 4 · MCDM Convergence"

            # ── Invent Phase 1: Brainstorm (3 experts) ────────────────────
            brainstorm_transcript: dict = {}
            for role in debate_roles:
                agent        = self.expert_map[role]
                display_role = self._display_role(role, proposal)
                bs_prompt    = self._invent_brainstorm_prompt(
                    role, proposal, state.final_need_statement,
                    case_packet_text, context, lang_instruction, lang_name, cjk_output,
                )
                bs_retry = self._grounded_round_retry_prompt(
                    proposal, lang_instruction, lang_name, role,
                    "Invent Phase 1 Brainstorm",
                    "Propose 1-2 solution concepts grounded in the validated Need Statement from your domain perspective.",
                    context,
                )
                bs_content = ask_and_record(
                    agent, display_role, invent_brainstorm_label, bs_prompt,
                    topic_guard=True, retry_prompt=bs_retry,
                )
                brainstorm_transcript[role] = bs_content
                context += f"\n\n[{invent_brainstorm_label} | {role}]\n{bs_content}"

            brainstorm_summary = EnhancedMedicalPanel._format_prior_round(brainstorm_transcript)
            brainstorm_full_text = "\n\n---\n\n".join(
                f"**{role}**\n\n{content}" for role, content in brainstorm_transcript.items()
            )

            # ── Invent Phase 2: Option Formation ─────────────────────────
            option_prompt = (
                f"{lang_instruction}\n\n"
                "You are the Option Formation Agent. The Invent Brainstorm is complete.\n"
                "Consolidate ALL brainstorm concepts into 3–5 distinct, implementable options.\n\n"
                f"Validated Need Statement:\n{state.final_need_statement}\n\n"
                f"Brainstorm concepts:\n{brainstorm_summary}\n\n"
                "For each option include: option name, core mechanism, domain origin, "
                "required resources, key risks, evidence needed, phased roadmap, candidate MCDM scores.\n\n"
                f"Write in {lang_name}."
            )
            option_retry = (
                f"{lang_instruction}\n\n"
                "Consolidate the brainstorm concepts below into 3–5 options. "
                "Do not provide examples from unrelated clinical areas.\n\n"
                f"{self._compact_shared_state(proposal, needs_brief, state.final_need_statement, state.evidence_gaps, state.risks)}\n\n"
                f"Brainstorm summary:\n{brainstorm_summary}\n\nWrite in {lang_name}."
            )
            option_text = ask_and_record(
                self.option_former, option_role, invent_option_label,
                option_prompt, topic_guard=True, retry_prompt=option_retry,
            )
            state.options = self._extract_options(option_text)
            option_scores = self._extract_mcdm_scores(option_text)
            if option_scores:
                state.mcdm_scores["option_formation"] = option_scores
            context += f"\n\n[{invent_option_label} | {option_role}]\n{option_text}"

            # ── Invent Phase 3: Multi-round Solution Debate (3 experts + Critical Review) ──
            sol_round_transcripts: list[dict] = []
            for round_idx in range(1, invent_rounds_clamped + 1):
                is_sol_first = round_idx == 1
                sol_rlabel = (
                    f"Invent 方案辯論 Round {round_idx}｜{'初始批判' if is_sol_first else '交叉挑戰'}"
                    if cjk_output else
                    f"Invent Solution Debate R{round_idx} · {'Critique' if is_sol_first else 'Cross-Challenge'}"
                )
                sol_round_transcript: dict = {}

                for role in debate_roles:
                    agent        = self.expert_map[role]
                    display_role = self._display_role(role, proposal)
                    if is_sol_first:
                        sol_prompt = self._invent_solution_critique_prompt(
                            role, proposal, brainstorm_summary, state.final_need_statement,
                            context, lang_instruction, lang_name, cjk_output,
                        )
                        sol_retry_focus = (
                            "Critique the proposed solution concepts from your domain perspective. "
                            "State which you support/oppose with specific reasons and identify the biggest cross-domain risk."
                        )
                    else:
                        prior_sol_summary = EnhancedMedicalPanel._format_prior_round(
                            sol_round_transcripts[-1], exclude_role=role,
                        )
                        sol_prompt = self._invent_solution_challenge_prompt(
                            role, proposal, prior_sol_summary, state.final_need_statement,
                            context, lang_instruction, lang_name, cjk_output, round_idx,
                        )
                        sol_retry_focus = (
                            "Respond to at least two other experts by name from the previous solution critique round. "
                            "State whether your preferred concept has changed and why."
                        )
                    sol_retry = self._grounded_round_retry_prompt(
                        proposal, lang_instruction, lang_name, role,
                        f"Invent Solution Debate Round {round_idx}",
                        sol_retry_focus, context,
                    )
                    sol_content = ask_and_record(
                        agent, display_role, sol_rlabel, sol_prompt,
                        topic_guard=True, retry_prompt=sol_retry,
                    )
                    sol_round_transcript[role] = sol_content
                    context += f"\n\n[{sol_rlabel} | {role}]\n{sol_content}"

                # Critical Review Agent replaces DA + Fact Checker in Invent
                self.critical_reviewer.reset()
                sol_summary_for_review = EnhancedMedicalPanel._format_prior_round(sol_round_transcript)
                cr_sol_prompt = (
                    f"{lang_instruction}\n\n"
                    f"You are the Critical Review Agent. This is the review after Invent Solution Debate Round {round_idx}.\n"
                    "Perform all three review functions (Devil's Advocate, Fact Checker, Bias Detector) "
                    "focused on the SOLUTION DEBATE context — challenge the consensus on which solution concept should win, "
                    "audit claims about technology readiness, market size, and regulatory pathways, "
                    "and flag any groupthink or optimism bias in the solution critique.\n\n"
                    f"Round {round_idx} solution debate transcript:\n{sol_summary_for_review}\n\n"
                    f"Write in {lang_name}."
                )
                cr_sol_fallback = (
                    "### " + (f"批判審查代理人｜方案辯論第 {round_idx} 輪審查" if cjk_output else f"Critical Review Agent | Invent Debate R{round_idx} Review") + "\n\n"
                    + ("**Part A – Devil's Advocate:** 方案辯論中存在技術可行性過度樂觀的集體假設，需要獨立技術驗證。\n\n"
                       "**Part B – Fact Checker:** 技術就緒程度與法規路徑的主張需要更多引用支持。\n\n"
                       "**Part C – Bias Detector:** 偵測到樂觀偏誤——各專家傾向低估自身方案的實作難度。"
                       if cjk_output else
                       "**Part A – Devil's Advocate:** There is collective overconfidence in technical feasibility; independent validation is required.\n\n"
                       "**Part B – Fact Checker:** Technology readiness and regulatory pathway claims need more citations.\n\n"
                       "**Part C – Bias Detector:** Optimism bias detected — experts tend to underestimate the implementation difficulty of their own concepts."
                    )
                )
                cr_sol_content = ask_and_record(
                    self.critical_reviewer, critical_role, sol_rlabel, cr_sol_prompt,
                    topic_guard=True, fallback_content=cr_sol_fallback,
                )
                sol_round_transcript["Critical Review Agent"] = cr_sol_content
                context += f"\n\n[{sol_rlabel} | {critical_role}]\n{cr_sol_content}"
                sol_round_transcripts.append(sol_round_transcript)

            # ── Invent Phase 4: MCDM Convergence ─────────────────────────
            self.evaluator.reset()
            invent_eval_prompt = (
                f"{lang_instruction}\n\n"
                "TASK: Perform MCDM Convergence on the solution debate transcript below. "
                "Do NOT ask for more input. Begin immediately.\n\n"
                "You are the Consolidated Evaluator performing Invent Phase MCDM Convergence.\n"
                "Your scores MUST be grounded in the solution debate below.\n\n"
                f"MCDM weights: System Impact {state.mcdm_weights['System Impact']:.0%} | "
                f"Implementability {state.mcdm_weights['Implementability']:.0%} | "
                f"Risk Control {state.mcdm_weights['Risk Control']:.0%} | "
                f"Innovation {state.mcdm_weights['Innovation']:.0%} | "
                f"Cost-Benefit {state.mcdm_weights['Cost-Benefit']:.0%}\n\n"
                "Deliverables:\n"
                "1. MCDM score table (0-10 per dimension per option, with debate citation)\n"
                "2. Weighted ranking of all options\n"
                "3. Sensitivity note (what changes if weights shift ±15%)\n"
                "4. Top recommended option with implementation roadmap\n"
                "5. Go / Hold / No-Go for each option with one-line rationale\n\n"
                f"=== FULL SOLUTION DEBATE TRANSCRIPT ===\n{context}\n=== END ===\n\n"
                f"Write in {lang_name}."
            )
            invent_mcdm_fallback = (
                "### " + ("整合評估者｜MCDM 收斂報告" if cjk_output else "Consolidated Evaluator | MCDM Convergence") + "\n\n"
                + ("**決策：** 所有方案暫列 Hold，待補充關鍵技術與法規驗證資料後重新評估。"
                   if cjk_output else
                   "**Decision:** All options listed as Hold pending supplementary technical and regulatory validation data.")
            )
            invent_final_report = ask_and_record(
                self.evaluator, evaluator_role, invent_mcdm_label, invent_eval_prompt,
                topic_guard=True, fallback_content=invent_mcdm_fallback,
            )
            context += f"\n\n[{invent_mcdm_label} | {evaluator_role}]\n{invent_final_report}"
            invent_scores = self._extract_mcdm_scores(invent_final_report)
            if invent_scores:
                state.mcdm_scores["invent_mcdm_convergence"] = invent_scores
                state.sensitivity_analysis = self._calculate_sensitivity(invent_scores, state.mcdm_weights)
            state.invent_brainstorm_text = brainstorm_full_text
            state.invent_options_text = option_text
            state.invent_debate_summary = "\n\n---\n\n".join(
                EnhancedMedicalPanel._format_prior_round(rt) for rt in sol_round_transcripts
            )
            state.invent_mcdm_report = invent_final_report
            state.final_report = final_report + f"\n\n---\n\n## Invent Phase MCDM Convergence\n\n{invent_final_report}"

        state.completed_at = datetime.now().isoformat(timespec="seconds")
        self.last_discovery_log = state.to_dict()
        self.last_discovery_log["stb_identify_intake"] = {
            "strategic_focus": state.project_context,
            "clinical_observation": proposal,
            "known_constraints": state.known_constraints,
            "evidence_available": state.evidence_available,
        }

        if status_callback:
            status_callback({
                "step": len(agenda),
                "total": len(agenda),
                "phase": rerate_label,
                "role": evaluator_role,
                "action": "討論完成" if cjk_output else "Discussion complete",
                "next_role": None,
                "next_phase": None,
                "agenda": agenda,
                "done": True,
            })

        quality_items = state.need_statement_quality
        if cjk_output:
            final_need_label = "最終需求陳述"
            version_history_label = "需求陳述版本紀錄"
            quality_report = (
                f"- 最終需求陳述：{state.final_need_statement or 'N/A'}\n"
                f"- 格式正確：{quality_items.get('format_ok')}\n"
                f"- 不含解決方案：{quality_items.get('solution_free')}\n"
                f"- 目標族群存在：{quality_items.get('has_target_population')}\n"
                f"- 可衡量結果存在：{quality_items.get('has_measurable_outcome')}\n"
                f"- 整體通過：{quality_items.get('passed')}"
            )
        else:
            final_need_label = "Final Need Statement"
            version_history_label = "Need Statement Version History"
            quality_report = (
                f"- Final Need Statement: {state.final_need_statement or 'N/A'}\n"
                f"- Format OK: {quality_items.get('format_ok')}\n"
                f"- Solution-free: {quality_items.get('solution_free')}\n"
                f"- Target population present: {quality_items.get('has_target_population')}\n"
                f"- Measurable outcome present: {quality_items.get('has_measurable_outcome')}\n"
                f"- Overall pass: {quality_items.get('passed')}"
            )
        need_versions_report = "\n".join(
            f"- {item.get('phase')} | {item.get('role')}: {item.get('statement')}"
            for item in state.need_statement_versions
            if item.get("statement") and not self._looks_like_placeholder_need(item.get("statement"))
        ) or "- N/A"
        identify_portfolio = state.identify_portfolio or final_report
        return (
            f"[{needs_brief_label}]\n{needs_brief}\n\n"
            f"[{discovery_label}]\n{context}\n\n"
            f"[{final_report_label}]\n{final_report}\n\n"
            f"[{identify_report_label}]\n{identify_portfolio}\n\n"
            f"[{final_need_label}]\n{state.final_need_statement or 'N/A'}\n\n"
            f"[{version_history_label}]\n{need_versions_report}\n\n"
            f"[{quality_label}]\n{quality_report}"
        )

if __name__ == "__main__":
    panel = EnhancedMedicalPanel()
    print("\n🌟 [Welcome to the Biodesign AI Expert Consultation System]")
    while True:
        try:
            proposal = input("\n📝 Please enter your clinical observation: ")
            if proposal.lower() in ['q', 'exit', 'quit']: break
            panel.run_discussion(proposal)
        except KeyboardInterrupt: break
