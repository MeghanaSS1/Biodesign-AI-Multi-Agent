import json
import os
import re
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


class EvidenceGrounder:
    def __init__(self, project_root: str = ".", timeout: float = 8.0):
        self.project_root = Path(project_root)
        self.timeout = timeout
        self.email = os.getenv("NCBI_EMAIL", "")
        self.api_key = os.getenv("NCBI_API_KEY", "")
        self.tfda_endpoint = os.getenv("TFDA_OPEN_DATA_URL", "")
        self.enabled = os.getenv("ENABLE_EVIDENCE_GROUNDING", "0").lower() not in {"0", "false", "no"}
        self.max_queries = int(os.getenv("EVIDENCE_MAX_QUERIES", "12"))
        self.query_count = 0
        self.cache = {}

    @staticmethod
    def _compact_query(text: str, max_terms: int = 14) -> str:
        cleaned = re.sub(r"https?://\S+", " ", text or "")
        cleaned = re.sub(r"[^\w\s\u4e00-\u9fff-]", " ", cleaned)
        tokens = [token for token in cleaned.split() if len(token) > 2]
        stop_words = {
            "the", "and", "for", "with", "that", "this", "from", "are", "was",
            "were", "into", "about", "需要", "可能", "目前", "因此", "以及", "是否",
        }
        terms = [token for token in tokens if token.lower() not in stop_words]
        return " ".join(terms[:max_terms]).strip()

    @staticmethod
    def _uses_cjk(text: str) -> bool:
        return bool(re.search(r"[\u4e00-\u9fff]", text or ""))

    def plan_queries(self, claim: str) -> dict:
        english_terms = {
            "氣管內管": "endotracheal tube",
            "插管": "intubation endotracheal tube",
            "翻身": "patient repositioning turning ICU",
            "滑脫": "dislodgement unplanned extubation",
            "移位": "tube displacement migration",
            "拔管": "unplanned extubation",
            "血氧": "hypoxemia oxygen saturation",
            "警報": "ventilator alarm alarm fatigue",
            "固定": "tube securement holder",
            "呼吸器": "mechanical ventilation ventilator",
            "加護病房": "ICU critical care",
            "感測": "sensor monitoring",
            "醫材": "medical device",
        }
        translated_terms = [term for key, term in english_terms.items() if key in (claim or "")]
        compact = self._compact_query(claim)
        clinical_query = " ".join(translated_terms[:6]) if translated_terms else compact
        device_query = " ".join(
            term for term in translated_terms
            if any(key in term for key in ["tube", "device", "holder", "sensor", "ventilator", "securement"])
        ) or clinical_query
        if self._uses_cjk(claim) and not translated_terms:
            clinical_query = compact
            device_query = compact
        return {
            "original": claim,
            "clinical_query": clinical_query[:240],
            "device_query": device_query[:240],
            "local_query": compact[:240],
        }

    def summarize_grounding(self, entries: list, max_items: int = 12) -> str:
        lines = []
        for entry in entries[:max_items]:
            query = entry.get("query_plan", {}).get("clinical_query") or entry.get("query", "")
            lines.append(f"- Claim/query: {query}")
            for item in entry.get("pubmed", [])[:2]:
                lines.append(f"  - PubMed PMID {item.get('pmid')}: {item.get('title')} ({item.get('pubdate')})")
            for item in entry.get("fda", [])[:2]:
                if item.get("error"):
                    continue
                label = item.get("device_name") or item.get("product_code") or "FDA device record"
                identifier = item.get("k_number") or item.get("pma_number") or item.get("product_code") or ""
                lines.append(f"  - {item.get('source')}: {label} {identifier}".strip())
            for item in entry.get("tfda", [])[:1]:
                if item.get("status") == "not_configured":
                    lines.append("  - TFDA: not configured")
                else:
                    lines.append(f"  - TFDA: {item.get('record')}")
            for item in entry.get("local_rag", [])[:1]:
                lines.append(f"  - Local RAG: {item.get('path')} :: {item.get('snippet')}")
            for error in entry.get("errors", [])[:2]:
                lines.append(f"  - {error.get('source')} error: {error.get('error')}")
        return "\n".join(lines) if lines else "No external grounding results available."

    def _get_json(self, url: str) -> dict:
        request = Request(url, headers={"User-Agent": "BiodesignEvidenceGrounder/0.1"})
        with urlopen(request, timeout=self.timeout) as response:
            return json.loads(response.read().decode("utf-8"))

    def search_pubmed(self, query: str, limit: int = 3) -> list:
        params = {
            "db": "pubmed",
            "term": query,
            "retmode": "json",
            "retmax": str(limit),
            "sort": "relevance",
        }
        if self.email:
            params["email"] = self.email
        if self.api_key:
            params["api_key"] = self.api_key
        search_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?" + urlencode(params)
        search_data = self._get_json(search_url)
        ids = search_data.get("esearchresult", {}).get("idlist", [])
        if not ids:
            return []

        summary_params = {"db": "pubmed", "id": ",".join(ids), "retmode": "json"}
        if self.email:
            summary_params["email"] = self.email
        if self.api_key:
            summary_params["api_key"] = self.api_key
        summary_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?" + urlencode(summary_params)
        summary_data = self._get_json(summary_url)
        result = summary_data.get("result", {})
        records = []
        for pmid in ids:
            item = result.get(pmid, {})
            if not item:
                continue
            records.append({
                "source": "PubMed",
                "pmid": pmid,
                "title": item.get("title", ""),
                "journal": item.get("fulljournalname", item.get("source", "")),
                "pubdate": item.get("pubdate", ""),
                "url": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
            })
        return records

    def search_openfda_devices(self, query: str, limit: int = 3) -> list:
        encoded = query.replace('"', '\\"')
        endpoints = [
            ("FDA 510(k)", "https://api.fda.gov/device/510k.json", f'(device_name:"{encoded}"+OR+statement_or_summary:"{encoded}")'),
            ("FDA Device Classification", "https://api.fda.gov/device/classification.json", f'(device_name:"{encoded}"+OR+medical_specialty_description:"{encoded}")'),
            ("FDA PMA", "https://api.fda.gov/device/pma.json", f'(generic_name:"{encoded}"+OR+device_name:"{encoded}")'),
        ]
        records = []
        for source, endpoint, search in endpoints:
            url = endpoint + "?" + urlencode({"search": search, "limit": str(limit)})
            try:
                data = self._get_json(url)
            except Exception as exc:
                records.append({"source": source, "error": str(exc)})
                continue
            for item in data.get("results", [])[:limit]:
                records.append({
                    "source": source,
                    "device_name": item.get("device_name") or item.get("generic_name") or item.get("openfda", {}).get("device_name", [""])[0],
                    "applicant": item.get("applicant") or item.get("applicant_name", ""),
                    "decision_date": item.get("decision_date") or item.get("date_received") or item.get("decision_code", ""),
                    "product_code": item.get("product_code") or item.get("openfda", {}).get("device_name", [""])[0],
                    "k_number": item.get("k_number", ""),
                    "pma_number": item.get("pma_number", ""),
                })
        return records[:limit * 3]

    def search_tfda(self, query: str, limit: int = 3) -> list:
        if not self.tfda_endpoint:
            return [{
                "source": "TFDA",
                "status": "not_configured",
                "note": "Set TFDA_OPEN_DATA_URL in .env to enable TFDA open-data lookup.",
            }]
        url = self.tfda_endpoint + ("&" if "?" in self.tfda_endpoint else "?") + urlencode({"q": query, "limit": str(limit)})
        data = self._get_json(url)
        if isinstance(data, list):
            items = data[:limit]
        else:
            items = data.get("results", data.get("data", []))[:limit]
        return [{"source": "TFDA", "record": item} for item in items]

    def search_local_rag(self, query: str, limit: int = 5) -> list:
        roots = [self.project_root / "plan", self.project_root / "reports"]
        query_terms = set(self._compact_query(query, max_terms=20).lower().split())
        matches = []
        for root in roots:
            if not root.exists():
                continue
            for path in root.rglob("*"):
                if path.suffix.lower() not in {".txt", ".md"} or not path.is_file():
                    continue
                try:
                    text = path.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                lowered = text.lower()
                score = sum(1 for term in query_terms if term in lowered)
                if score <= 0:
                    continue
                snippet_start = 0
                for term in query_terms:
                    idx = lowered.find(term)
                    if idx >= 0:
                        snippet_start = max(idx - 120, 0)
                        break
                snippet = re.sub(r"\s+", " ", text[snippet_start:snippet_start + 420]).strip()
                matches.append({
                    "source": "Local RAG",
                    "path": str(path),
                    "score": score,
                    "snippet": snippet,
                })
        matches.sort(key=lambda item: item["score"], reverse=True)
        return matches[:limit]

    def ground_claim(self, claim: str) -> dict:
        query_plan = self.plan_queries(claim)
        query = query_plan["clinical_query"] or query_plan["local_query"]
        cache_key = json.dumps(query_plan, ensure_ascii=False, sort_keys=True)
        if cache_key in self.cache:
            return {**self.cache[cache_key], "cached": True}
        result = {
            "claim": claim,
            "query": query,
            "query_plan": query_plan,
            "enabled": self.enabled,
            "cached": False,
            "pubmed": [],
            "fda": [],
            "tfda": [],
            "local_rag": [],
            "errors": [],
        }
        if not self.enabled or not query:
            return result
        if self.query_count >= self.max_queries:
            result["errors"].append({"source": "EvidenceGrounder", "error": "max query budget reached"})
            return result
        self.query_count += 1
        for key, func, planned_query in [
            ("pubmed", self.search_pubmed, query_plan["clinical_query"]),
            ("fda", self.search_openfda_devices, query_plan["device_query"]),
            ("tfda", self.search_tfda, query_plan["device_query"]),
            ("local_rag", self.search_local_rag, query_plan["local_query"]),
        ]:
            try:
                result[key] = func(planned_query or query)
            except Exception as exc:
                result["errors"].append({"source": key, "error": str(exc)})
        self.cache[cache_key] = result
        return result
