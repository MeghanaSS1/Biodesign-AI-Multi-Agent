# Biodesign AI Roundtable 使用指南

這個專案是一個「醫療創新需求分析與辯論系統」。它不是單純的聊天機器人，而是把一個臨床觀察丟進多個 AI 專家角色中，讓它們依照 STB Biodesign Identify 流程進行需求定義、跨領域討論、風險挑戰、需求篩選與驗證規劃。

適合用來把「我在臨床上看到一個問題」整理成比較完整的：

- Need Statement
- Need Profile
- Need Screening
- Validation Plan
- Need Criteria
- 法規與智財風險
- 商業與病患可近性考量
- Evidence gaps
- Discovery Log

## 專案整體規劃

這個專案的目標是把臨床觀察轉換成一個可追蹤、可討論、可驗證的 Biodesign workflow。第一階段先建立多代理人討論系統，讓不同專家角色能針對同一個臨床問題提出立場、批判假設、標記證據缺口並修正 Need Statement。第二階段會把討論過程結構化，產生 Discovery Log，讓每一輪討論、claim、evidence gap、風險與 Need Statement 版本都能被追蹤。第三階段會逐步加入外部 evidence grounding，例如 PubMed、FDA、TFDA 與本地 RAG，讓系統不只是「會討論」，也能標記哪些主張有初步證據、哪些仍需要人工查證。最終目標是做成一個可用於課程展示、研究討論、早期產品探索與醫療創新需求定義的輔助工具。

目前版本已完成多代理人 workflow、MCDM 權重調整、Markdown 報告、JSON Discovery Log、Need Statement 品質檢查、初步 evidence grounding 與模型 fallback。下一步可以優化 evidence query 品質、UI 呈現、結果比較、專案案例庫，以及更正式的文獻/法規/專利查證流程。

## STB Biodesign Identify 工作台方向

目前系統已加入 Identify 階段閉環，目標是從「生成 Need Statement」推進到「產生可篩選、可驗證、可推進的 Need Profile」。

新增輸出包含：

- Need Profile：把需求陳述展開成目標族群、臨床情境、現行流程、痛點、利害關係人、替代方案、證據強度與未知事項
- Need Screening：依 Clinical Impact、Problem Frequency、Stakeholder Urgency、Current Solution Gap、Market Potential、Technical Feasibility、Regulatory / Reimbursement Risk、Strategic Fit 進行 1-5 分評估
- Validation Plan：產生關鍵假設、訪談問題、觀察任務、待蒐集資料、成功標準與 red flags
- Need Criteria：為後續 Invent 階段建立 Must-Haves、Nice-to-Haves、Constraints、Success Metrics 與 No-Go Boundaries
- Mentor Review Summary：整理強項、弱項，以及進入解方發想前必須驗證的事項

這個版本的產品邊界仍停留在 **Identify 階段**。系統會保留現有跨域專家圓桌作為討論與風險辨識來源，但最後會額外產生一份 `STB Identify Portfolio`，讓團隊可以拿去做 mentor review、需求篩選與下一輪臨床驗證。

預設流程已改為 **Identify-only**：系統不會產生 Invent 階段的產品方案或實作路徑，而是停在 Need Screening、Validation Plan 與 Need Criteria。這可以避免團隊在需求尚未驗證前過早跳到 solution brainstorming。

## 專案在做什麼

使用者輸入一段 clinical observation，例如：

```text
護理人員在幫插管病人翻身時，經常發生氣管內管滑脫或移位，導致病人血氧驟降。
```

系統會依序啟動 7 個合併後的 AI 角色：

- Intake Analyzer：整合 Case Packet Extractor + Needs Source Agent，整理原始觀察與臨床現象
- Clinical-Technical Expert：整合 Clinical Physician + Biomedical Engineer，分析臨床真實性、患者安全與工程限制
- Regulatory-Business Expert：整合 Regulatory Expert + Market/IP Expert，評估法規、智財、市場、採購與給付風險
- Human-Patient Expert：整合 Human Factors + Patient Access，分析工作流、人因、患者體驗與健康公平性
- Option Formation Agent：在 Invent 模式中把概念整合成 3-5 個方案
- Critical Review Agent：整合 Devil's Advocate + Fact Checker + Bias Detector，挑戰假設、查核主張與標記偏誤
- Consolidated Evaluator：整合 MCDM scoring、ranking、final decision 與 Identify Portfolio

最後會輸出兩種檔案：

- `reports/biodesign_report_YYYYMMDD_HHMMSS.md`：人可以閱讀的 Markdown 報告
- `reports/biodesign_discovery_log_YYYYMMDD_HHMMSS.json`：可追蹤的 Discovery Log，方便後續分析、比較、展示

報告中會包含 `STB Identify 需求檔案` 區段；JSON log 中也會包含：

- `identify_portfolio`
- `need_profile`
- `screening_result`
- `validation_plan`
- `need_criteria`

## 專案檔案說明

```text
app.py                    Streamlit 網頁介面
medical_expert_panel.py   多代理人工作流主程式
prompts.py                各 AI 角色的 system prompt
evidence_grounding.py     PubMed / FDA / TFDA / local RAG 查詢輔助
.env.example              API key 與模型設定範本
requirements.txt          Python 套件需求
reports/                  產出報告與 JSON log
plan/                     參考文件與 paper
scratch/                  測試或實驗用腳本
```

## 第一次使用

### 1. 建立自己的 `.env`

請先複製 `.env.example` 成 `.env`：

```bash
cp .env.example .env
```

然後用文字編輯器打開 `.env`，換成自己的 API key。

重要：不要把 `.env` 傳給別人，也不要上傳到 GitHub。裡面會放自己的 API key。

### 2. 選擇模型來源

在 `.env` 裡設定：

```env
LLM_PROVIDER=OLLAMA
```

可選值：

```text
OLLAMA        使用本機 Ollama
OLLAMA_CLOUD  使用 Ollama Cloud
OPENAI        使用 OpenAI
GEMINI        使用 Google Gemini
OMLX          使用本機 oMLX OpenAI-compatible server
```

## 如何更換自己的 API Key

### 選項 A：使用本機 Ollama

適合：不想把資料送到雲端、已有本機模型。

`.env` 設定：

```env
LLM_PROVIDER=OLLAMA
OLLAMA_MODEL=gemma4:e4b
OLLAMA_URL=http://localhost:11434/v1
```

使用前需要先在本機啟動 Ollama，並確認模型已下載。

### 選項 B：使用 Ollama Cloud

適合：想用雲端模型，設定相對簡單。

`.env` 設定：

```env
LLM_PROVIDER=OLLAMA_CLOUD
OLLAMA_API_KEY=你的_ollama_api_key
OLLAMA_CLOUD_MODEL=gpt-oss:120b
OLLAMA_CLOUD_URL=https://ollama.com/v1
```

### 選項 C：使用 OpenAI

適合：想用 OpenAI API。

`.env` 設定：

```env
LLM_PROVIDER=OPENAI
OPENAI_API_KEY=你的_openai_api_key
```

目前程式預設使用 `GPT_4O_MINI`。如果要換 OpenAI model，需要到 `medical_expert_panel.py` 裡調整 `_create_model()` 的 OpenAI 區塊。

### 選項 D：使用 Gemini

適合：想用 Google Gemini API。

`.env` 設定：

```env
LLM_PROVIDER=GEMINI
GOOGLE_API_KEY=你的_google_api_key
```

注意：Gemini 免費層常有 rate limit，所以系統每次呼叫會自動等一下，完整討論可能比較慢。

### 選項 E：使用 oMLX

適合：本機有 oMLX server，且提供 OpenAI-compatible API。

`.env` 設定：

```env
LLM_PROVIDER=OMLX
OMLX_MODEL=Qwen3.5-9B-MLX-4bit
OMLX_URL=http://127.0.0.1:8989/v1
OMLX_API_KEY=omlx
```

## 自動模型 fallback

如果主要模型失敗，系統可以自動切換到下一個 provider。

`.env`：

```env
MODEL_FALLBACK_CHAIN=OLLAMA,OMLX,GEMINI,OPENAI
```

例如目前是 `LLM_PROVIDER=OLLAMA_CLOUD`，但 Ollama Cloud 失敗，系統會依照 fallback chain 嘗試下一個可用模型。

提醒：fallback 只在模型呼叫失敗時啟動；如果 API key 沒填、模型沒安裝或本機服務沒開，該 provider 仍然會失敗。

## Evidence Grounding

系統有外部 evidence grounding 功能，可查：

- PubMed
- openFDA device APIs
- TFDA endpoint
- 專案內的 `plan/`、`reports/` 文字資料

預設是關閉，因為開啟後會把萃取出的 claim query 傳到外部 API。

`.env`：

```env
ENABLE_EVIDENCE_GROUNDING=0
EVIDENCE_MAX_QUERIES=12
NCBI_EMAIL=your_email@example.com
NCBI_API_KEY=
TFDA_OPEN_DATA_URL=
```

在網頁側邊欄也可以打開：

```text
Use external evidence APIs
```

建議：

- 只是 demo 或測試流程：保持關閉
- 需要正式查 PubMed/FDA：再打開
- 如果 clinical observation 有敏感病患資訊，請先去識別化再輸入

## 如何啟動

一般情況下：

```bash
.venv2/bin/python -m streamlit run app.py --server.port 8504
```

成功後打開：

```text
http://localhost:8504
```

如果 `8504` 被占用，可以換成：

```bash
.venv2/bin/python -m streamlit run app.py --server.port 8505
```

## 如何使用網頁

1. 打開 `http://localhost:8504`
2. 在下方輸入 clinical observation
3. 側邊欄可調整 MCDM 權重
4. 如需外部查證，打開 `Use external evidence APIs`
5. 等待多代理人逐步討論
6. 下載：
   - Full Report Markdown
   - Discovery Log JSON

## 建議輸入格式

請輸入「臨床觀察」，不要直接輸入產品想法。

比較好的輸入：

```text
護理人員在幫插管病人翻身時，經常發生氣管內管滑脫或移位，導致病人血氧驟降。
```

比較不建議：

```text
我想做一個 AI 感測器固定氣管內管。
```

原因是 Biodesign 流程希望先定義需求，再討論方案，避免太早鎖定某個產品。

## 常見問題

### 1. 為什麼跑很久？

這個系統不是單次聊天，而是多個 agent 依序討論。一次完整流程會呼叫很多次模型，使用雲端模型或 Gemini 時可能需要幾分鐘。

### 2. 為什麼 Critical Review Agent 還是說需要查證？

Critical Review Agent 裡的 fact-checking 功能不是「保證每句都是真的」，而是：

- 標記 claim
- 標記 evidence gap
- 指出需要 PubMed / FDA / TFDA / pilot data 查證的內容

如果打開 Evidence Grounding，系統會把部分 claim query 送去外部資料源找初步證據。

### 3. 為什麼 Need Statement 被判定不合格？

Need Statement 應該是 solution-free，也就是不要包含具體產品或技術，例如 app、sensor、AI、device。

好的形式：

```text
一種能夠協助加護病房插管病人在翻身照護期間降低非預期拔管風險的方法。
```

不好的形式：

```text
一種使用 AI 感測器偵測氣管內管滑脫的裝置。
```

### 4. API key 放哪裡？

放在 `.env`，不要放在程式碼裡。

### 5. 可以多人共用同一份 API key 嗎？

技術上可以，但不建議。每個人最好用自己的 key，避免額度、費用、log 和隱私混在一起。

## 給共同執行者的最短流程

如果你只想快速跑一次：

1. 複製 `.env.example` 成 `.env`
2. 在 `.env` 填自己的 API key
3. 設定 `LLM_PROVIDER`
4. 執行：

```bash
.venv2/bin/python -m streamlit run app.py --server.port 8504
```

5. 打開 `http://localhost:8504`
6. 輸入 clinical observation
7. 下載 Markdown report 和 JSON Discovery Log

## 注意事項

- 請勿輸入可辨識病患身分的資訊。
- 外部 evidence grounding 開啟後，claim query 會送到外部 API。
- AI 產出不是醫療建議，也不是法規或智財結論，只能當作 early-stage Biodesign 討論輔助。
- 真正要做研究、投稿、產品化或臨床驗證前，仍需人工查證文獻、法規與專利。
