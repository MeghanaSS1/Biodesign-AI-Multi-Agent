# Biodesign AI Roundtable User Guide

This project is a medical innovation need analysis and debate system. It is not just a chatbot. It takes a raw clinical observation and sends it through a reduced 7-agent Biodesign-style workflow: need definition, cross-disciplinary discussion, risk challenge, optional option formation, and MCDM scoring.

It is designed to help turn "a clinical problem I observed" into a more structured early-stage innovation package:

- Need Statement
- Need Profile
- Need Screening
- Validation Plan
- Need Criteria
- Regulatory and IP risks
- Business and patient access considerations
- Evidence gaps
- Discovery Log

## Project Roadmap

The goal of this project is to turn raw clinical observations into a traceable, debatable, and verifiable Biodesign workflow. The first stage builds a multi-agent discussion system where different expert roles can analyze the same clinical problem, state their positions, critique assumptions, form solution options, and perform MCDM scoring. The second stage structures the discussion into a Discovery Log so each discussion round, claim, evidence gap, risk, option, and Need Statement version can be tracked. The third stage gradually adds external evidence grounding, including PubMed, FDA, TFDA, and local RAG, so the system can identify which claims have preliminary supporting evidence and which still require human verification. The long-term goal is to create a practical support tool for course presentations, research discussions, early product exploration, and medical innovation need definition.

The current version already includes the multi-agent workflow, adjustable MCDM weights, Markdown reports, JSON Discovery Logs, Need Statement quality checks, preliminary evidence grounding, and model fallback. Future improvements may include better evidence query planning, richer UI visualization, result comparison across cases, a reusable project case library, and a more formal literature/regulatory/patent verification pipeline.

## What This Project Does

The user enters a clinical observation, for example:

```text
Nurses often experience endotracheal tube displacement or dislodgement when repositioning intubated patients, causing sudden oxygen desaturation.
```

The system then activates 7 merged AI roles in sequence:

- Intake Analyzer: combines Case Packet Extractor + Needs Source Agent
- Clinical-Technical Expert: combines Clinical Physician + Biomedical Engineer
- Regulatory-Business Expert: combines Regulatory Expert + Market/IP Expert
- Human-Patient Expert: combines Human Factors + Patient Access
- Option Formation Agent: consolidates concepts into 3-5 options in Invent mode
- Critical Review Agent: combines Devil's Advocate + Fact Checker + Bias Detector
- Consolidated Evaluator: handles MCDM scoring, ranking, final decision, and Identify Portfolio

The system generates two output files:

- `reports/biodesign_report_YYYYMMDD_HHMMSS.md`: a human-readable Markdown report
- `reports/biodesign_discovery_log_YYYYMMDD_HHMMSS.json`: a structured Discovery Log for tracking, comparison, and later analysis

## Project Files

```text
app.py                    Streamlit web interface
medical_expert_panel.py   Main multi-agent workflow
prompts.py                System prompts for each AI role
evidence_grounding.py     PubMed / FDA / TFDA / local RAG helper
.env.example              API key and model configuration template
requirements.txt          Python package requirements
reports/                  Generated reports and JSON logs
plan/                     Reference papers and planning documents
scratch/                  Test and experimental scripts
```

## First-Time Setup

### 1. Create Your Own `.env`

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Then open `.env` with a text editor and replace the placeholder values with your own API keys.

Important: do not share your `.env` file and do not upload it to GitHub. It contains private API keys.

### 2. Choose a Model Provider

Set this in `.env`:

```env
LLM_PROVIDER=OLLAMA
```

Available options:

```text
OLLAMA        Use local Ollama
OLLAMA_CLOUD  Use Ollama Cloud
OPENAI        Use OpenAI
GEMINI        Use Google Gemini
OMLX          Use a local oMLX OpenAI-compatible server
```

## How to Use Your Own API Key

### Option A: Local Ollama

Best for users who want local execution and do not want to send data to a cloud model.

`.env` settings:

```env
LLM_PROVIDER=OLLAMA
OLLAMA_MODEL=gemma4:e4b
OLLAMA_URL=http://localhost:11434/v1
```

Before using this option, make sure Ollama is running locally and the model has already been downloaded.

### Option B: Ollama Cloud

Best for users who want a cloud model with relatively simple setup.

`.env` settings:

```env
LLM_PROVIDER=OLLAMA_CLOUD
OLLAMA_API_KEY=your_ollama_api_key
OLLAMA_CLOUD_MODEL=gpt-oss:120b
OLLAMA_CLOUD_URL=https://ollama.com/v1
```

### Option C: OpenAI

Best for users who want to use the OpenAI API.

`.env` settings:

```env
LLM_PROVIDER=OPENAI
OPENAI_API_KEY=your_openai_api_key
```

The current code uses `GPT_4O_MINI` by default. To change the OpenAI model, edit the OpenAI section in `_create_model()` inside `medical_expert_panel.py`.

### Option D: Gemini

Best for users who want to use the Google Gemini API.

`.env` settings:

```env
LLM_PROVIDER=GEMINI
GOOGLE_API_KEY=your_google_api_key
```

Note: Gemini free-tier access often has rate limits. The system waits between calls, so a full discussion may take longer.

### Option E: oMLX

Best for users who have a local oMLX server that provides an OpenAI-compatible API.

`.env` settings:

```env
LLM_PROVIDER=OMLX
OMLX_MODEL=Qwen3.5-9B-MLX-4bit
OMLX_URL=http://127.0.0.1:8989/v1
OMLX_API_KEY=omlx
```

## Automatic Model Fallback

If the main model fails, the system can automatically switch to the next provider.

`.env`:

```env
MODEL_FALLBACK_CHAIN=OLLAMA,OMLX,GEMINI,OPENAI
```

For example, if `LLM_PROVIDER=OLLAMA_CLOUD` fails, the system will try the next provider in the fallback chain.

Reminder: fallback only activates when a model call fails. If an API key is missing, a model is not installed, or a local service is not running, that provider will still fail.

## Evidence Grounding

The system includes optional external evidence grounding through:

- PubMed
- openFDA device APIs
- TFDA endpoint
- Local text files in `plan/` and `reports/`

This feature is disabled by default because enabling it sends extracted claim queries to external APIs.

`.env`:

```env
ENABLE_EVIDENCE_GROUNDING=0
EVIDENCE_MAX_QUERIES=12
NCBI_EMAIL=your_email@example.com
NCBI_API_KEY=
TFDA_OPEN_DATA_URL=
```

You can also enable it from the web sidebar:

```text
Use external evidence APIs
```

Recommendations:

- For demos or workflow testing: keep it off
- For formal PubMed/FDA lookup: turn it on
- If the clinical observation contains sensitive patient information, de-identify it before entering it

## How to Run

Usually:

```bash
.venv2/bin/python -m streamlit run app.py --server.port 8504
```

Then open:

```text
http://localhost:8504
```

If port `8504` is already in use, use another port:

```bash
.venv2/bin/python -m streamlit run app.py --server.port 8505
```

## How to Use the Web App

1. Open `http://localhost:8504`
2. Enter a clinical observation at the bottom
3. Adjust MCDM weights in the sidebar if needed
4. Turn on `Use external evidence APIs` only if external lookup is needed
5. Wait for the multi-agent discussion to finish
6. Download:
   - Full Report Markdown
   - Discovery Log JSON

## Recommended Input Format

Enter a clinical observation, not a product idea.

Better input:

```text
Nurses often experience endotracheal tube displacement or dislodgement when repositioning intubated patients, causing sudden oxygen desaturation.
```

Less ideal input:

```text
I want to build an AI sensor to secure the endotracheal tube.
```

The reason is that Biodesign should first define the need before discussing a specific product or technology.

## Frequently Asked Questions

### 1. Why does it take a long time?

This system is not a single chatbot response. It runs multiple AI agents sequentially. A full workflow may require many model calls, especially when using cloud models or Gemini.

### 2. Why does the Critical Review Agent still say that evidence is needed?

The fact-checking function inside the Critical Review Agent is not meant to guarantee that every statement is true. Its role is to:

- Flag claims
- Mark evidence gaps
- Suggest whether PubMed / FDA / TFDA / pilot data is needed

If Evidence Grounding is enabled, the system sends selected claim queries to external data sources for preliminary evidence lookup.

### 3. Why did the Need Statement quality check fail?

A Need Statement should be solution-free. It should not include a specific product or technology such as app, sensor, AI, or device.

Good format:

```text
A way to help intubated ICU patients reduce unplanned extubation risk during repositioning care.
```

Poor format:

```text
An AI sensor device that detects endotracheal tube displacement.
```

### 4. Where should I put my API key?

Put it in `.env`, not directly inside the code.

### 5. Can multiple people share one API key?

Technically yes, but it is not recommended. Each person should use their own key so usage limits, costs, logs, and privacy concerns do not get mixed together.

## Short Workflow for a Collaborator

If you only want to run it once:

1. Copy `.env.example` to `.env`
2. Fill in your own API key
3. Set `LLM_PROVIDER`
4. Run:

```bash
.venv2/bin/python -m streamlit run app.py --server.port 8504
```

5. Open `http://localhost:8504`
6. Enter a clinical observation
7. Download the Markdown report and JSON Discovery Log

## Important Notes

- Do not enter identifiable patient information.
- If external evidence grounding is enabled, claim queries will be sent to external APIs.
- AI output is not medical advice, regulatory advice, or legal/IP advice. It is only an early-stage Biodesign discussion aid.
- Before using the output for research, publication, product development, or clinical validation, literature, regulatory, and patent claims must still be manually verified.
