# STB Biodesign Agent Blueprint

這份文件整理目前專案如何收斂成「STB Biodesign Identify Agent」。

## 產品定位

這個 agent 的任務不是幫使用者直接想產品，而是協助團隊從臨床觀察走到一個可被驗證、可被篩選、可被 mentor 討論的 Top Need。

核心邊界：

- 做 Identify
- 不做 solution brainstorming
- 不直接生成產品概念
- 不把法規、智財或醫療結論包裝成確定事實
- 所有高風險主張都要轉成 evidence gap 或 validation task

## 主要使用流程

1. Strategic Focus
   - 臨床領域
   - 照護場域
   - 目標利害關係人
   - 團隊能力
   - 市場/區域焦點
   - 風險偏好

2. Clinical Observation Intake
   - 原始觀察
   - 訪談筆記
   - shadowing notes
   - workflow notes
   - 痛點 bullet
   - 既有 need statement

3. Observation Structuring
   - Observation ID
   - Context
   - Stakeholder
   - Observed behavior
   - Pain point
   - Current workaround
   - Evidence type
   - Confidence

4. Insight Extraction
   - 重複痛點
   - workflow bottleneck
   - stakeholder frustration
   - safety risk
   - time/cost burden
   - communication failure
   - current workaround pattern

5. Need Statement Builder
   - 產生 solution-free need statement
   - 檢查 target population
   - 檢查 clinical context
   - 檢查 desired outcome
   - 檢查是否偷渡 solution

6. Need Profile Builder
   - 將一句 need statement 展開成完整 need profile
   - 讓需求變得 screenable、validatable、actionable

7. Need Screening
   - Clinical Impact
   - Problem Frequency
   - Stakeholder Urgency
   - Current Solution Gap
   - Market Potential
   - Technical Feasibility
   - Regulatory / Reimbursement Risk
   - Strategic Fit

8. Validation Plan
   - key assumptions
   - validation questions
   - stakeholders to interview
   - observation tasks
   - data to collect
   - success criteria
   - red flags

9. Mentor Review Summary
   - what is strong
   - what is weak
   - what must be validated before brainstorming solutions
   - Go / Hold / No-Go recommendation

## Agent 角色設計

目前專案收斂為 7 個合併後的 agent，避免回到過多角色造成流程冗長與輸出重複。

| Reduced Agent | Covers |
| --- | --- |
| Intake Analyzer | Case Packet Extractor + Needs Source Agent |
| Clinical-Technical Expert | Clinical Physician + Biomedical Engineer |
| Regulatory-Business Expert | Regulatory Expert + Market/IP Expert |
| Human-Patient Expert | Human Factors + Patient Access |
| Option Formation Agent | Consolidates ideas into 3-5 options |
| Critical Review Agent | Devil's Advocate + Fact Checker + Bias Detector |
| Consolidated Evaluator | MCDM scoring + ranking + final decision |

## 標準輸出 Schema

每次執行建議都產生同一個 JSON schema：

```json
{
  "project_context": {},
  "observations": [],
  "insights": [],
  "need_statement_versions": [],
  "final_need_statement": "",
  "need_statement_quality": {},
  "need_profile": {},
  "screening": {
    "scores": [],
    "overall_score": null,
    "recommendation": ""
  },
  "evidence_gaps": [],
  "validation_plan": {},
  "mentor_review": {},
  "next_actions": []
}
```

Markdown 報告可以從這個 JSON 產生，避免 agent 只回一大段文字後難以重用。

## 目前專案已具備的能力

- Streamlit UI
- 多代理人討論流程
- Identify-only 模式
- Need Statement 品質檢查
- Markdown report
- JSON discovery log
- Evidence grounding 開關
- PubMed / openFDA / TFDA / local RAG 初步查詢
- MCDM 權重調整
- Identify Portfolio 輸出

## 目前最大缺口

1. 缺少 Strategic Focus 輸入
2. Observation 還不是結構化資料
3. Need Profile 主要靠 Markdown 文字，還沒有穩定 schema
4. Screening 分數不容易被後續比較或排序
5. 目前仍保留 Option Formation Agent，容易偏向 Invent
6. Evidence grounding 查詢品質還需要改善
7. 尚未有固定測試案例來檢查 need statement 是否符合 Biodesign 原則

## 建議下一版 MVP

優先做這 5 件事：

1. 把 UI 改成 STB Identify Intake
   - Strategic Focus
   - Clinical Observation
   - Known Constraints
   - Evidence available

2. 新增 Observation Card schema
   - 即使使用者只輸入一段文字，也先轉成 card

3. 將 Identify Portfolio 改成結構化 JSON first
   - Markdown 只當顯示與下載格式

4. 隱藏或停用 Invent 相關 agent
   - Option Formation Agent 預設不出現在 Identify 流程

5. 加入 10 組測試案例
   - 每組都有 expected quality gates
   - 檢查是否 solution-free
   - 檢查是否產生 validation plan

## 最小可行版本定義

MVP 成功標準：

- 使用者輸入一段臨床觀察後，agent 能產生一份完整 Need Portfolio
- Need Statement 不含產品、裝置、AI、sensor、app 等解方字眼
- 每個 screening score 都有 rationale、confidence、missing evidence
- 每份輸出都有至少 5 個具體 validation questions
- Mentor Review 能明確說出 Go / Hold / No-Go
- JSON log 可被後續比較、排序、重新載入

## 建議命名

產品名稱可以暫定：

- STB Biodesign Identify Agent
- Biodesign Need Discovery Agent
- STB Identify AI Workbench

目前 repo 裡的 `Biodesign AI Roundtable` 可以保留作為展示名稱，但正式產品邏輯應改以 `Identify Agent` 為中心。
