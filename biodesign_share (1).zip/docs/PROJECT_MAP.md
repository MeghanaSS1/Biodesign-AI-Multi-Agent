# Project Map

這份文件是專案的快速整理版。完整使用說明仍以 `README.md` 為主。

## 一句話

這是一個 STB Biodesign Identify 階段的多代理人工作台：使用者輸入臨床觀察，系統透過多個 AI 專家角色討論，最後產生 Need Statement、Need Profile、Need Screening、Validation Plan、Need Criteria、Markdown 報告與 JSON Discovery Log。

## 主要入口

| 檔案 | 用途 |
| --- | --- |
| `app.py` | Streamlit 網頁介面。負責聊天畫面、側邊欄設定、結果下載與最新報告讀取。 |
| `medical_expert_panel.py` | 核心多代理人 workflow。負責模型建立、fallback、agent 設定、討論流程、報告與 discovery log 產生。 |
| `prompts.py` | 所有 AI 專家角色的 system prompt。 |
| `evidence_grounding.py` | PubMed、openFDA、TFDA 與本地 `plan/`、`reports/` 查詢輔助。 |
| `requirements.txt` | Python 套件需求。 |
| `.env.example` | API key、模型 provider、evidence grounding 設定範本。 |

## 資料夾角色

| 資料夾 | 建議用途 |
| --- | --- |
| `reports/` | 系統產出的 Markdown report 與 JSON discovery log。屬於可再生輸出。 |
| `plan/` | 報告、簡報、產品計畫與參考 paper。屬於專案知識庫。 |
| `scratch/` | 實驗、連線測試、臨時驗證腳本。可保留，但不視為正式入口。 |
| `archive/` | 舊版資料與舊腳本。只供追溯，不建議新功能繼續依賴。 |
| `docs/` | 專案導覽、維護紀錄、架構說明。 |

## 目前建議執行方式

```bash
.venv2/bin/python -m streamlit run app.py --server.port 8504
```

打開：

```text
http://localhost:8504
```

如果 `8504` 被占用，改用 `8505` 或其他空 port。

## 建議維護規則

1. 正式功能優先放在根目錄核心檔案，或未來再拆成 `src/`。
2. 新的手動測試、模型連線測試、一次性檢查放在 `scratch/`。
3. 系統產生的報告放在 `reports/`，不要手動改成唯一真相。
4. 舊流程放在 `archive/`，避免和目前 workflow 混用。
5. API key 只放 `.env`，不要寫進 README、程式碼或報告。
6. 要提交或分享專案時，排除 `.env`、虛擬環境、快取、log、zip、產出報告。

## 後續可整理項目

- 將核心程式拆成 `src/biodesign_roundtable/`，讓 `app.py` 保持薄介面。
- 把 `scratch/` 中仍有價值的測試整理成正式測試。
- 將 `reports/` 分成年月資料夾，避免產出變多後難找。
- 為 `medical_expert_panel.py` 補一組不呼叫外部模型的 smoke test。
- 將 README 分成「使用指南」與「開發指南」，降低單一文件長度。
